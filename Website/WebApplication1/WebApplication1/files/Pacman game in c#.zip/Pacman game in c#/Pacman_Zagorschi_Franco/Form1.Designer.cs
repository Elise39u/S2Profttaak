﻿namespace Pacman_Zagorschi_Franco
{
    partial class Form1
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.timer3 = new System.Windows.Forms.Timer(this.components);
            this.timer4 = new System.Windows.Forms.Timer(this.components);
            this.timer5 = new System.Windows.Forms.Timer(this.components);
            this.timer6 = new System.Windows.Forms.Timer(this.components);
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.ghost3 = new System.Windows.Forms.Label();
            this.ghost4 = new System.Windows.Forms.Label();
            this.ghost2 = new System.Windows.Forms.Label();
            this.ghost1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.score = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.label76 = new System.Windows.Forms.Label();
            this.label77 = new System.Windows.Forms.Label();
            this.label78 = new System.Windows.Forms.Label();
            this.label79 = new System.Windows.Forms.Label();
            this.label80 = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this.label82 = new System.Windows.Forms.Label();
            this.label83 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.label84 = new System.Windows.Forms.Label();
            this.label85 = new System.Windows.Forms.Label();
            this.label86 = new System.Windows.Forms.Label();
            this.label87 = new System.Windows.Forms.Label();
            this.label88 = new System.Windows.Forms.Label();
            this.label89 = new System.Windows.Forms.Label();
            this.label90 = new System.Windows.Forms.Label();
            this.label91 = new System.Windows.Forms.Label();
            this.label92 = new System.Windows.Forms.Label();
            this.label94 = new System.Windows.Forms.Label();
            this.label93 = new System.Windows.Forms.Label();
            this.label95 = new System.Windows.Forms.Label();
            this.label96 = new System.Windows.Forms.Label();
            this.label98 = new System.Windows.Forms.Label();
            this.label97 = new System.Windows.Forms.Label();
            this.label99 = new System.Windows.Forms.Label();
            this.label100 = new System.Windows.Forms.Label();
            this.label101 = new System.Windows.Forms.Label();
            this.label102 = new System.Windows.Forms.Label();
            this.label103 = new System.Windows.Forms.Label();
            this.label104 = new System.Windows.Forms.Label();
            this.label105 = new System.Windows.Forms.Label();
            this.label106 = new System.Windows.Forms.Label();
            this.label107 = new System.Windows.Forms.Label();
            this.label108 = new System.Windows.Forms.Label();
            this.label109 = new System.Windows.Forms.Label();
            this.label110 = new System.Windows.Forms.Label();
            this.label111 = new System.Windows.Forms.Label();
            this.label112 = new System.Windows.Forms.Label();
            this.label113 = new System.Windows.Forms.Label();
            this.label114 = new System.Windows.Forms.Label();
            this.label115 = new System.Windows.Forms.Label();
            this.label116 = new System.Windows.Forms.Label();
            this.label117 = new System.Windows.Forms.Label();
            this.label118 = new System.Windows.Forms.Label();
            this.label119 = new System.Windows.Forms.Label();
            this.label120 = new System.Windows.Forms.Label();
            this.label121 = new System.Windows.Forms.Label();
            this.label122 = new System.Windows.Forms.Label();
            this.label123 = new System.Windows.Forms.Label();
            this.label125 = new System.Windows.Forms.Label();
            this.label126 = new System.Windows.Forms.Label();
            this.label127 = new System.Windows.Forms.Label();
            this.label128 = new System.Windows.Forms.Label();
            this.label129 = new System.Windows.Forms.Label();
            this.label130 = new System.Windows.Forms.Label();
            this.label131 = new System.Windows.Forms.Label();
            this.label132 = new System.Windows.Forms.Label();
            this.label133 = new System.Windows.Forms.Label();
            this.label134 = new System.Windows.Forms.Label();
            this.label135 = new System.Windows.Forms.Label();
            this.label136 = new System.Windows.Forms.Label();
            this.label137 = new System.Windows.Forms.Label();
            this.label138 = new System.Windows.Forms.Label();
            this.label139 = new System.Windows.Forms.Label();
            this.label140 = new System.Windows.Forms.Label();
            this.label143 = new System.Windows.Forms.Label();
            this.label144 = new System.Windows.Forms.Label();
            this.label145 = new System.Windows.Forms.Label();
            this.label146 = new System.Windows.Forms.Label();
            this.label147 = new System.Windows.Forms.Label();
            this.label148 = new System.Windows.Forms.Label();
            this.label149 = new System.Windows.Forms.Label();
            this.label150 = new System.Windows.Forms.Label();
            this.label151 = new System.Windows.Forms.Label();
            this.label152 = new System.Windows.Forms.Label();
            this.label153 = new System.Windows.Forms.Label();
            this.label154 = new System.Windows.Forms.Label();
            this.label155 = new System.Windows.Forms.Label();
            this.label156 = new System.Windows.Forms.Label();
            this.label157 = new System.Windows.Forms.Label();
            this.label158 = new System.Windows.Forms.Label();
            this.label159 = new System.Windows.Forms.Label();
            this.label160 = new System.Windows.Forms.Label();
            this.label161 = new System.Windows.Forms.Label();
            this.label162 = new System.Windows.Forms.Label();
            this.label163 = new System.Windows.Forms.Label();
            this.label164 = new System.Windows.Forms.Label();
            this.label165 = new System.Windows.Forms.Label();
            this.label166 = new System.Windows.Forms.Label();
            this.label167 = new System.Windows.Forms.Label();
            this.label168 = new System.Windows.Forms.Label();
            this.label169 = new System.Windows.Forms.Label();
            this.label170 = new System.Windows.Forms.Label();
            this.label171 = new System.Windows.Forms.Label();
            this.label172 = new System.Windows.Forms.Label();
            this.label173 = new System.Windows.Forms.Label();
            this.label174 = new System.Windows.Forms.Label();
            this.label175 = new System.Windows.Forms.Label();
            this.label176 = new System.Windows.Forms.Label();
            this.label177 = new System.Windows.Forms.Label();
            this.label178 = new System.Windows.Forms.Label();
            this.label179 = new System.Windows.Forms.Label();
            this.label180 = new System.Windows.Forms.Label();
            this.label181 = new System.Windows.Forms.Label();
            this.label182 = new System.Windows.Forms.Label();
            this.label183 = new System.Windows.Forms.Label();
            this.label184 = new System.Windows.Forms.Label();
            this.label185 = new System.Windows.Forms.Label();
            this.label186 = new System.Windows.Forms.Label();
            this.label187 = new System.Windows.Forms.Label();
            this.label188 = new System.Windows.Forms.Label();
            this.label189 = new System.Windows.Forms.Label();
            this.label190 = new System.Windows.Forms.Label();
            this.label191 = new System.Windows.Forms.Label();
            this.label192 = new System.Windows.Forms.Label();
            this.label193 = new System.Windows.Forms.Label();
            this.label194 = new System.Windows.Forms.Label();
            this.label195 = new System.Windows.Forms.Label();
            this.label196 = new System.Windows.Forms.Label();
            this.label199 = new System.Windows.Forms.Label();
            this.label198 = new System.Windows.Forms.Label();
            this.label200 = new System.Windows.Forms.Label();
            this.label201 = new System.Windows.Forms.Label();
            this.label202 = new System.Windows.Forms.Label();
            this.label203 = new System.Windows.Forms.Label();
            this.label204 = new System.Windows.Forms.Label();
            this.label205 = new System.Windows.Forms.Label();
            this.label206 = new System.Windows.Forms.Label();
            this.label207 = new System.Windows.Forms.Label();
            this.label208 = new System.Windows.Forms.Label();
            this.label209 = new System.Windows.Forms.Label();
            this.label210 = new System.Windows.Forms.Label();
            this.label211 = new System.Windows.Forms.Label();
            this.label212 = new System.Windows.Forms.Label();
            this.label213 = new System.Windows.Forms.Label();
            this.label214 = new System.Windows.Forms.Label();
            this.label197 = new System.Windows.Forms.Label();
            this.label215 = new System.Windows.Forms.Label();
            this.label216 = new System.Windows.Forms.Label();
            this.label217 = new System.Windows.Forms.Label();
            this.label218 = new System.Windows.Forms.Label();
            this.label219 = new System.Windows.Forms.Label();
            this.label220 = new System.Windows.Forms.Label();
            this.label221 = new System.Windows.Forms.Label();
            this.label222 = new System.Windows.Forms.Label();
            this.label223 = new System.Windows.Forms.Label();
            this.label224 = new System.Windows.Forms.Label();
            this.label225 = new System.Windows.Forms.Label();
            this.label226 = new System.Windows.Forms.Label();
            this.label227 = new System.Windows.Forms.Label();
            this.label228 = new System.Windows.Forms.Label();
            this.label229 = new System.Windows.Forms.Label();
            this.label230 = new System.Windows.Forms.Label();
            this.label231 = new System.Windows.Forms.Label();
            this.label232 = new System.Windows.Forms.Label();
            this.label233 = new System.Windows.Forms.Label();
            this.label234 = new System.Windows.Forms.Label();
            this.label235 = new System.Windows.Forms.Label();
            this.label236 = new System.Windows.Forms.Label();
            this.label237 = new System.Windows.Forms.Label();
            this.label238 = new System.Windows.Forms.Label();
            this.label239 = new System.Windows.Forms.Label();
            this.label240 = new System.Windows.Forms.Label();
            this.label241 = new System.Windows.Forms.Label();
            this.label242 = new System.Windows.Forms.Label();
            this.label243 = new System.Windows.Forms.Label();
            this.label244 = new System.Windows.Forms.Label();
            this.label245 = new System.Windows.Forms.Label();
            this.label246 = new System.Windows.Forms.Label();
            this.label247 = new System.Windows.Forms.Label();
            this.label248 = new System.Windows.Forms.Label();
            this.label249 = new System.Windows.Forms.Label();
            this.label250 = new System.Windows.Forms.Label();
            this.label251 = new System.Windows.Forms.Label();
            this.label252 = new System.Windows.Forms.Label();
            this.label256 = new System.Windows.Forms.Label();
            this.label257 = new System.Windows.Forms.Label();
            this.label258 = new System.Windows.Forms.Label();
            this.label259 = new System.Windows.Forms.Label();
            this.label260 = new System.Windows.Forms.Label();
            this.label261 = new System.Windows.Forms.Label();
            this.label262 = new System.Windows.Forms.Label();
            this.label263 = new System.Windows.Forms.Label();
            this.label264 = new System.Windows.Forms.Label();
            this.label265 = new System.Windows.Forms.Label();
            this.label272 = new System.Windows.Forms.Label();
            this.label273 = new System.Windows.Forms.Label();
            this.label274 = new System.Windows.Forms.Label();
            this.label280 = new System.Windows.Forms.Label();
            this.label281 = new System.Windows.Forms.Label();
            this.label282 = new System.Windows.Forms.Label();
            this.label283 = new System.Windows.Forms.Label();
            this.label284 = new System.Windows.Forms.Label();
            this.label266 = new System.Windows.Forms.Label();
            this.label267 = new System.Windows.Forms.Label();
            this.label268 = new System.Windows.Forms.Label();
            this.label269 = new System.Windows.Forms.Label();
            this.label270 = new System.Windows.Forms.Label();
            this.label271 = new System.Windows.Forms.Label();
            this.label275 = new System.Windows.Forms.Label();
            this.label276 = new System.Windows.Forms.Label();
            this.label277 = new System.Windows.Forms.Label();
            this.label278 = new System.Windows.Forms.Label();
            this.label279 = new System.Windows.Forms.Label();
            this.label285 = new System.Windows.Forms.Label();
            this.label286 = new System.Windows.Forms.Label();
            this.label287 = new System.Windows.Forms.Label();
            this.label288 = new System.Windows.Forms.Label();
            this.label289 = new System.Windows.Forms.Label();
            this.label290 = new System.Windows.Forms.Label();
            this.label293 = new System.Windows.Forms.Label();
            this.label294 = new System.Windows.Forms.Label();
            this.label295 = new System.Windows.Forms.Label();
            this.label296 = new System.Windows.Forms.Label();
            this.label297 = new System.Windows.Forms.Label();
            this.label298 = new System.Windows.Forms.Label();
            this.label299 = new System.Windows.Forms.Label();
            this.label300 = new System.Windows.Forms.Label();
            this.label301 = new System.Windows.Forms.Label();
            this.label302 = new System.Windows.Forms.Label();
            this.label291 = new System.Windows.Forms.Label();
            this.label292 = new System.Windows.Forms.Label();
            this.label303 = new System.Windows.Forms.Label();
            this.label304 = new System.Windows.Forms.Label();
            this.label305 = new System.Windows.Forms.Label();
            this.label306 = new System.Windows.Forms.Label();
            this.label307 = new System.Windows.Forms.Label();
            this.label308 = new System.Windows.Forms.Label();
            this.label309 = new System.Windows.Forms.Label();
            this.label310 = new System.Windows.Forms.Label();
            this.label311 = new System.Windows.Forms.Label();
            this.label312 = new System.Windows.Forms.Label();
            this.label313 = new System.Windows.Forms.Label();
            this.label314 = new System.Windows.Forms.Label();
            this.label315 = new System.Windows.Forms.Label();
            this.label316 = new System.Windows.Forms.Label();
            this.label317 = new System.Windows.Forms.Label();
            this.label318 = new System.Windows.Forms.Label();
            this.label319 = new System.Windows.Forms.Label();
            this.label320 = new System.Windows.Forms.Label();
            this.label321 = new System.Windows.Forms.Label();
            this.label322 = new System.Windows.Forms.Label();
            this.label323 = new System.Windows.Forms.Label();
            this.label324 = new System.Windows.Forms.Label();
            this.label325 = new System.Windows.Forms.Label();
            this.label327 = new System.Windows.Forms.Label();
            this.label326 = new System.Windows.Forms.Label();
            this.label328 = new System.Windows.Forms.Label();
            this.label329 = new System.Windows.Forms.Label();
            this.label330 = new System.Windows.Forms.Label();
            this.label331 = new System.Windows.Forms.Label();
            this.label332 = new System.Windows.Forms.Label();
            this.label333 = new System.Windows.Forms.Label();
            this.label334 = new System.Windows.Forms.Label();
            this.label335 = new System.Windows.Forms.Label();
            this.label336 = new System.Windows.Forms.Label();
            this.label337 = new System.Windows.Forms.Label();
            this.label338 = new System.Windows.Forms.Label();
            this.label339 = new System.Windows.Forms.Label();
            this.label340 = new System.Windows.Forms.Label();
            this.label341 = new System.Windows.Forms.Label();
            this.timer8 = new System.Windows.Forms.Timer(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.pacman = new System.Windows.Forms.PictureBox();
            this.powermod = new System.Windows.Forms.Timer(this.components);
            this.timer7 = new System.Windows.Forms.Timer(this.components);
            this.timer9 = new System.Windows.Forms.Timer(this.components);
            this.ghostmangiato = new System.Windows.Forms.Timer(this.components);
            this.label124 = new System.Windows.Forms.Label();
            this.label141 = new System.Windows.Forms.Label();
            this.powermod1 = new System.Windows.Forms.Timer(this.components);
            this.attendo = new System.Windows.Forms.Timer(this.components);
            this.label254 = new System.Windows.Forms.Label();
            this.label255 = new System.Windows.Forms.Label();
            this.label253 = new System.Windows.Forms.Label();
            this.label142 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pacman)).BeginInit();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Interval = 16;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Black;
            this.label1.Font = new System.Drawing.Font("Segoe UI Black", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Image = global::Pacman_Zagorschi_Franco.Properties.Resources.score;
            this.label1.Location = new System.Drawing.Point(16, 400);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 30);
            this.label1.TabIndex = 129;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Black;
            this.label2.Font = new System.Drawing.Font("Segoe UI Black", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Image = global::Pacman_Zagorschi_Franco.Properties.Resources.lives;
            this.label2.Location = new System.Drawing.Point(226, 399);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 30);
            this.label2.TabIndex = 130;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.Black;
            this.label3.Font = new System.Drawing.Font("Segoe UI Black", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Image = global::Pacman_Zagorschi_Franco.Properties.Resources.getready;
            this.label3.Location = new System.Drawing.Point(123, 222);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(125, 19);
            this.label3.TabIndex = 133;
            this.label3.Text = "          ";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // timer2
            // 
            this.timer2.Interval = 3000;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // timer3
            // 
            this.timer3.Interval = 1;
            this.timer3.Tick += new System.EventHandler(this.timer3_Tick);
            // 
            // timer4
            // 
            this.timer4.Interval = 1;
            this.timer4.Tick += new System.EventHandler(this.timer4_Tick);
            // 
            // timer5
            // 
            this.timer5.Interval = 1;
            this.timer5.Tick += new System.EventHandler(this.timer5_Tick);
            // 
            // timer6
            // 
            this.timer6.Interval = 1;
            this.timer6.Tick += new System.EventHandler(this.timer6_Tick);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pictureBox2.Image = global::Pacman_Zagorschi_Franco.Properties.Resources._1sx;
            this.pictureBox2.Location = new System.Drawing.Point(318, 402);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(22, 22);
            this.pictureBox2.TabIndex = 132;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pictureBox1.Image = global::Pacman_Zagorschi_Franco.Properties.Resources._1sx;
            this.pictureBox1.Location = new System.Drawing.Point(297, 402);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(22, 22);
            this.pictureBox1.TabIndex = 131;
            this.pictureBox1.TabStop = false;
            // 
            // ghost3
            // 
            this.ghost3.BackColor = System.Drawing.Color.Transparent;
            this.ghost3.Cursor = System.Windows.Forms.Cursors.Default;
            this.ghost3.ForeColor = System.Drawing.Color.Transparent;
            this.ghost3.Image = global::Pacman_Zagorschi_Franco.Properties.Resources.vup;
            this.ghost3.Location = new System.Drawing.Point(176, 185);
            this.ghost3.Margin = new System.Windows.Forms.Padding(0);
            this.ghost3.Name = "ghost3";
            this.ghost3.Size = new System.Drawing.Size(18, 18);
            this.ghost3.TabIndex = 127;
            // 
            // ghost4
            // 
            this.ghost4.BackColor = System.Drawing.Color.Transparent;
            this.ghost4.Cursor = System.Windows.Forms.Cursors.Default;
            this.ghost4.ForeColor = System.Drawing.Color.Transparent;
            this.ghost4.Image = global::Pacman_Zagorschi_Franco.Properties.Resources.gup;
            this.ghost4.Location = new System.Drawing.Point(199, 185);
            this.ghost4.Margin = new System.Windows.Forms.Padding(0);
            this.ghost4.Name = "ghost4";
            this.ghost4.Size = new System.Drawing.Size(18, 18);
            this.ghost4.TabIndex = 126;
            // 
            // ghost2
            // 
            this.ghost2.BackColor = System.Drawing.Color.Transparent;
            this.ghost2.Cursor = System.Windows.Forms.Cursors.Default;
            this.ghost2.ForeColor = System.Drawing.Color.Transparent;
            this.ghost2.Image = global::Pacman_Zagorschi_Franco.Properties.Resources.aup;
            this.ghost2.Location = new System.Drawing.Point(154, 185);
            this.ghost2.Margin = new System.Windows.Forms.Padding(0);
            this.ghost2.Name = "ghost2";
            this.ghost2.Size = new System.Drawing.Size(18, 18);
            this.ghost2.TabIndex = 125;
            // 
            // ghost1
            // 
            this.ghost1.BackColor = System.Drawing.Color.Transparent;
            this.ghost1.Cursor = System.Windows.Forms.Cursors.Default;
            this.ghost1.ForeColor = System.Drawing.Color.Transparent;
            this.ghost1.Image = global::Pacman_Zagorschi_Franco.Properties.Resources.rup;
            this.ghost1.Location = new System.Drawing.Point(176, 150);
            this.ghost1.Margin = new System.Windows.Forms.Padding(0);
            this.ghost1.Name = "ghost1";
            this.ghost1.Size = new System.Drawing.Size(18, 18);
            this.ghost1.TabIndex = 124;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(102, 266);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(2, 2);
            this.label4.TabIndex = 134;
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(111, 266);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(2, 2);
            this.label5.TabIndex = 135;
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(129, 266);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(2, 2);
            this.label6.TabIndex = 137;
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(120, 266);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(2, 2);
            this.label7.TabIndex = 136;
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(165, 266);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(2, 2);
            this.label8.TabIndex = 141;
            // 
            // label9
            // 
            this.label9.BackColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(156, 266);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(2, 2);
            this.label9.TabIndex = 140;
            // 
            // label10
            // 
            this.label10.BackColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(147, 266);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(2, 2);
            this.label10.TabIndex = 139;
            // 
            // label11
            // 
            this.label11.BackColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(138, 266);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(2, 2);
            this.label11.TabIndex = 138;
            // 
            // label12
            // 
            this.label12.BackColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(94, 266);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(2, 2);
            this.label12.TabIndex = 149;
            // 
            // label13
            // 
            this.label13.BackColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(78, 266);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(2, 2);
            this.label13.TabIndex = 148;
            // 
            // label14
            // 
            this.label14.BackColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(69, 266);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(2, 2);
            this.label14.TabIndex = 147;
            // 
            // label15
            // 
            this.label15.BackColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(60, 266);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(2, 2);
            this.label15.TabIndex = 146;
            // 
            // label16
            // 
            this.label16.BackColor = System.Drawing.Color.White;
            this.label16.Location = new System.Drawing.Point(52, 266);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(2, 2);
            this.label16.TabIndex = 145;
            // 
            // label17
            // 
            this.label17.BackColor = System.Drawing.Color.White;
            this.label17.Location = new System.Drawing.Point(43, 266);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(2, 2);
            this.label17.TabIndex = 144;
            // 
            // label18
            // 
            this.label18.BackColor = System.Drawing.Color.White;
            this.label18.Location = new System.Drawing.Point(247, 266);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(2, 2);
            this.label18.TabIndex = 163;
            // 
            // label19
            // 
            this.label19.BackColor = System.Drawing.Color.White;
            this.label19.Location = new System.Drawing.Point(238, 266);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(2, 2);
            this.label19.TabIndex = 162;
            // 
            // label20
            // 
            this.label20.BackColor = System.Drawing.Color.White;
            this.label20.Location = new System.Drawing.Point(229, 266);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(2, 2);
            this.label20.TabIndex = 161;
            // 
            // label21
            // 
            this.label21.BackColor = System.Drawing.Color.White;
            this.label21.Location = new System.Drawing.Point(220, 266);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(2, 2);
            this.label21.TabIndex = 160;
            // 
            // label22
            // 
            this.label22.BackColor = System.Drawing.Color.White;
            this.label22.Location = new System.Drawing.Point(211, 266);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(2, 2);
            this.label22.TabIndex = 159;
            // 
            // label23
            // 
            this.label23.BackColor = System.Drawing.Color.White;
            this.label23.Location = new System.Drawing.Point(202, 266);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(2, 2);
            this.label23.TabIndex = 158;
            // 
            // label24
            // 
            this.label24.BackColor = System.Drawing.Color.White;
            this.label24.Location = new System.Drawing.Point(318, 266);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(2, 2);
            this.label24.TabIndex = 157;
            // 
            // label25
            // 
            this.label25.BackColor = System.Drawing.Color.White;
            this.label25.Location = new System.Drawing.Point(310, 266);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(2, 2);
            this.label25.TabIndex = 156;
            // 
            // label26
            // 
            this.label26.BackColor = System.Drawing.Color.White;
            this.label26.Location = new System.Drawing.Point(301, 266);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(2, 2);
            this.label26.TabIndex = 155;
            // 
            // label27
            // 
            this.label27.BackColor = System.Drawing.Color.White;
            this.label27.Location = new System.Drawing.Point(292, 266);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(2, 2);
            this.label27.TabIndex = 154;
            // 
            // label28
            // 
            this.label28.BackColor = System.Drawing.Color.White;
            this.label28.Location = new System.Drawing.Point(283, 266);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(2, 2);
            this.label28.TabIndex = 153;
            // 
            // label29
            // 
            this.label29.BackColor = System.Drawing.Color.White;
            this.label29.Location = new System.Drawing.Point(274, 266);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(2, 2);
            this.label29.TabIndex = 152;
            // 
            // label30
            // 
            this.label30.BackColor = System.Drawing.Color.White;
            this.label30.Location = new System.Drawing.Point(265, 266);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(2, 2);
            this.label30.TabIndex = 151;
            // 
            // label31
            // 
            this.label31.BackColor = System.Drawing.Color.White;
            this.label31.Location = new System.Drawing.Point(256, 266);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(2, 2);
            this.label31.TabIndex = 150;
            // 
            // score
            // 
            this.score.AutoSize = true;
            this.score.Font = new System.Drawing.Font("Segoe UI Black", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.score.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(51)))));
            this.score.Location = new System.Drawing.Point(93, 399);
            this.score.Name = "score";
            this.score.Size = new System.Drawing.Size(24, 28);
            this.score.TabIndex = 164;
            this.score.Text = "0";
            // 
            // label43
            // 
            this.label43.BackColor = System.Drawing.Color.White;
            this.label43.Location = new System.Drawing.Point(165, 284);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(2, 2);
            this.label43.TabIndex = 180;
            // 
            // label44
            // 
            this.label44.BackColor = System.Drawing.Color.White;
            this.label44.Location = new System.Drawing.Point(165, 293);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(2, 2);
            this.label44.TabIndex = 181;
            // 
            // label32
            // 
            this.label32.BackColor = System.Drawing.Color.White;
            this.label32.Location = new System.Drawing.Point(165, 275);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(2, 2);
            this.label32.TabIndex = 179;
            // 
            // label45
            // 
            this.label45.BackColor = System.Drawing.Color.White;
            this.label45.Location = new System.Drawing.Point(202, 293);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(2, 2);
            this.label45.TabIndex = 185;
            // 
            // label46
            // 
            this.label46.BackColor = System.Drawing.Color.White;
            this.label46.Location = new System.Drawing.Point(202, 284);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(2, 2);
            this.label46.TabIndex = 184;
            // 
            // label47
            // 
            this.label47.BackColor = System.Drawing.Color.White;
            this.label47.Location = new System.Drawing.Point(202, 275);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(2, 2);
            this.label47.TabIndex = 183;
            // 
            // label49
            // 
            this.label49.BackColor = System.Drawing.Color.White;
            this.label49.Location = new System.Drawing.Point(326, 266);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(2, 2);
            this.label49.TabIndex = 186;
            // 
            // label50
            // 
            this.label50.BackColor = System.Drawing.Color.White;
            this.label50.Location = new System.Drawing.Point(35, 266);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(2, 2);
            this.label50.TabIndex = 187;
            // 
            // label33
            // 
            this.label33.BackColor = System.Drawing.Color.White;
            this.label33.Location = new System.Drawing.Point(94, 302);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(2, 2);
            this.label33.TabIndex = 196;
            // 
            // label34
            // 
            this.label34.BackColor = System.Drawing.Color.White;
            this.label34.Location = new System.Drawing.Point(165, 302);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(2, 2);
            this.label34.TabIndex = 195;
            // 
            // label35
            // 
            this.label35.BackColor = System.Drawing.Color.White;
            this.label35.Location = new System.Drawing.Point(156, 302);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(2, 2);
            this.label35.TabIndex = 194;
            // 
            // label36
            // 
            this.label36.BackColor = System.Drawing.Color.White;
            this.label36.Location = new System.Drawing.Point(147, 302);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(2, 2);
            this.label36.TabIndex = 193;
            // 
            // label37
            // 
            this.label37.BackColor = System.Drawing.Color.White;
            this.label37.Location = new System.Drawing.Point(138, 302);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(2, 2);
            this.label37.TabIndex = 192;
            // 
            // label38
            // 
            this.label38.BackColor = System.Drawing.Color.White;
            this.label38.Location = new System.Drawing.Point(129, 302);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(2, 2);
            this.label38.TabIndex = 191;
            // 
            // label39
            // 
            this.label39.BackColor = System.Drawing.Color.White;
            this.label39.Location = new System.Drawing.Point(120, 302);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(2, 2);
            this.label39.TabIndex = 190;
            // 
            // label40
            // 
            this.label40.BackColor = System.Drawing.Color.White;
            this.label40.Location = new System.Drawing.Point(111, 302);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(2, 2);
            this.label40.TabIndex = 189;
            // 
            // label41
            // 
            this.label41.BackColor = System.Drawing.Color.White;
            this.label41.Location = new System.Drawing.Point(102, 302);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(2, 2);
            this.label41.TabIndex = 188;
            // 
            // label42
            // 
            this.label42.BackColor = System.Drawing.Color.White;
            this.label42.Location = new System.Drawing.Point(202, 302);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(2, 2);
            this.label42.TabIndex = 205;
            // 
            // label48
            // 
            this.label48.BackColor = System.Drawing.Color.White;
            this.label48.Location = new System.Drawing.Point(274, 302);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(2, 2);
            this.label48.TabIndex = 204;
            // 
            // label51
            // 
            this.label51.BackColor = System.Drawing.Color.White;
            this.label51.Location = new System.Drawing.Point(265, 302);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(2, 2);
            this.label51.TabIndex = 203;
            // 
            // label52
            // 
            this.label52.BackColor = System.Drawing.Color.White;
            this.label52.Location = new System.Drawing.Point(256, 302);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(2, 2);
            this.label52.TabIndex = 202;
            // 
            // label53
            // 
            this.label53.BackColor = System.Drawing.Color.White;
            this.label53.Location = new System.Drawing.Point(247, 302);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(2, 2);
            this.label53.TabIndex = 201;
            // 
            // label54
            // 
            this.label54.BackColor = System.Drawing.Color.White;
            this.label54.Location = new System.Drawing.Point(238, 302);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(2, 2);
            this.label54.TabIndex = 200;
            // 
            // label55
            // 
            this.label55.BackColor = System.Drawing.Color.White;
            this.label55.Location = new System.Drawing.Point(229, 302);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(2, 2);
            this.label55.TabIndex = 199;
            // 
            // label56
            // 
            this.label56.BackColor = System.Drawing.Color.White;
            this.label56.Location = new System.Drawing.Point(220, 302);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(2, 2);
            this.label56.TabIndex = 198;
            // 
            // label57
            // 
            this.label57.BackColor = System.Drawing.Color.White;
            this.label57.Location = new System.Drawing.Point(211, 302);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(2, 2);
            this.label57.TabIndex = 197;
            // 
            // label58
            // 
            this.label58.BackColor = System.Drawing.Color.White;
            this.label58.Location = new System.Drawing.Point(94, 293);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(2, 2);
            this.label58.TabIndex = 208;
            // 
            // label59
            // 
            this.label59.BackColor = System.Drawing.Color.White;
            this.label59.Location = new System.Drawing.Point(94, 284);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(2, 2);
            this.label59.TabIndex = 207;
            // 
            // label60
            // 
            this.label60.BackColor = System.Drawing.Color.White;
            this.label60.Location = new System.Drawing.Point(94, 275);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(2, 2);
            this.label60.TabIndex = 206;
            // 
            // label61
            // 
            this.label61.BackColor = System.Drawing.Color.White;
            this.label61.Location = new System.Drawing.Point(274, 293);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(2, 2);
            this.label61.TabIndex = 211;
            // 
            // label62
            // 
            this.label62.BackColor = System.Drawing.Color.White;
            this.label62.Location = new System.Drawing.Point(274, 284);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(2, 2);
            this.label62.TabIndex = 210;
            // 
            // label63
            // 
            this.label63.BackColor = System.Drawing.Color.White;
            this.label63.Location = new System.Drawing.Point(274, 275);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(2, 2);
            this.label63.TabIndex = 209;
            // 
            // label64
            // 
            this.label64.BackColor = System.Drawing.Color.White;
            this.label64.Location = new System.Drawing.Point(183, 302);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(2, 2);
            this.label64.TabIndex = 213;
            // 
            // label65
            // 
            this.label65.BackColor = System.Drawing.Color.White;
            this.label65.Location = new System.Drawing.Point(174, 302);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(2, 2);
            this.label65.TabIndex = 212;
            // 
            // label66
            // 
            this.label66.BackColor = System.Drawing.Color.White;
            this.label66.Location = new System.Drawing.Point(192, 302);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(2, 2);
            this.label66.TabIndex = 214;
            // 
            // label67
            // 
            this.label67.BackColor = System.Drawing.Color.White;
            this.label67.Location = new System.Drawing.Point(334, 293);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(2, 2);
            this.label67.TabIndex = 217;
            // 
            // label68
            // 
            this.label68.BackColor = System.Drawing.Color.White;
            this.label68.Location = new System.Drawing.Point(334, 284);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(2, 2);
            this.label68.TabIndex = 216;
            // 
            // label69
            // 
            this.label69.BackColor = System.Drawing.Color.White;
            this.label69.Location = new System.Drawing.Point(334, 275);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(2, 2);
            this.label69.TabIndex = 215;
            // 
            // label70
            // 
            this.label70.BackColor = System.Drawing.Color.White;
            this.label70.Location = new System.Drawing.Point(334, 266);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(2, 2);
            this.label70.TabIndex = 218;
            // 
            // label71
            // 
            this.label71.BackColor = System.Drawing.Color.Black;
            this.label71.Image = ((System.Drawing.Image)(resources.GetObject("label71.Image")));
            this.label71.Location = new System.Drawing.Point(330, 298);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(10, 10);
            this.label71.TabIndex = 222;
            // 
            // label72
            // 
            this.label72.BackColor = System.Drawing.Color.White;
            this.label72.Location = new System.Drawing.Point(326, 302);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(2, 2);
            this.label72.TabIndex = 221;
            // 
            // label73
            // 
            this.label73.BackColor = System.Drawing.Color.White;
            this.label73.Location = new System.Drawing.Point(318, 302);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(2, 2);
            this.label73.TabIndex = 220;
            // 
            // label74
            // 
            this.label74.BackColor = System.Drawing.Color.White;
            this.label74.Location = new System.Drawing.Point(310, 302);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(2, 2);
            this.label74.TabIndex = 219;
            // 
            // label76
            // 
            this.label76.BackColor = System.Drawing.Color.White;
            this.label76.Location = new System.Drawing.Point(310, 311);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(2, 2);
            this.label76.TabIndex = 226;
            // 
            // label77
            // 
            this.label77.BackColor = System.Drawing.Color.White;
            this.label77.Location = new System.Drawing.Point(310, 338);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(2, 2);
            this.label77.TabIndex = 225;
            // 
            // label78
            // 
            this.label78.BackColor = System.Drawing.Color.White;
            this.label78.Location = new System.Drawing.Point(310, 329);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(2, 2);
            this.label78.TabIndex = 224;
            // 
            // label79
            // 
            this.label79.BackColor = System.Drawing.Color.White;
            this.label79.Location = new System.Drawing.Point(310, 320);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(2, 2);
            this.label79.TabIndex = 223;
            // 
            // label80
            // 
            this.label80.BackColor = System.Drawing.Color.White;
            this.label80.Location = new System.Drawing.Point(301, 338);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(2, 2);
            this.label80.TabIndex = 230;
            // 
            // label81
            // 
            this.label81.BackColor = System.Drawing.Color.White;
            this.label81.Location = new System.Drawing.Point(292, 338);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(2, 2);
            this.label81.TabIndex = 229;
            // 
            // label82
            // 
            this.label82.BackColor = System.Drawing.Color.White;
            this.label82.Location = new System.Drawing.Point(283, 338);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(2, 2);
            this.label82.TabIndex = 228;
            // 
            // label83
            // 
            this.label83.BackColor = System.Drawing.Color.White;
            this.label83.Location = new System.Drawing.Point(274, 338);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(2, 2);
            this.label83.TabIndex = 227;
            // 
            // label75
            // 
            this.label75.BackColor = System.Drawing.Color.White;
            this.label75.Location = new System.Drawing.Point(274, 311);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(2, 2);
            this.label75.TabIndex = 233;
            // 
            // label84
            // 
            this.label84.BackColor = System.Drawing.Color.White;
            this.label84.Location = new System.Drawing.Point(274, 329);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(2, 2);
            this.label84.TabIndex = 232;
            // 
            // label85
            // 
            this.label85.BackColor = System.Drawing.Color.White;
            this.label85.Location = new System.Drawing.Point(274, 320);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(2, 2);
            this.label85.TabIndex = 231;
            // 
            // label86
            // 
            this.label86.BackColor = System.Drawing.Color.White;
            this.label86.Location = new System.Drawing.Point(238, 311);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(2, 2);
            this.label86.TabIndex = 237;
            // 
            // label87
            // 
            this.label87.BackColor = System.Drawing.Color.White;
            this.label87.Location = new System.Drawing.Point(238, 329);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(2, 2);
            this.label87.TabIndex = 236;
            // 
            // label88
            // 
            this.label88.BackColor = System.Drawing.Color.White;
            this.label88.Location = new System.Drawing.Point(238, 320);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(2, 2);
            this.label88.TabIndex = 235;
            // 
            // label89
            // 
            this.label89.BackColor = System.Drawing.Color.White;
            this.label89.Location = new System.Drawing.Point(238, 338);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(2, 2);
            this.label89.TabIndex = 234;
            // 
            // label90
            // 
            this.label90.BackColor = System.Drawing.Color.White;
            this.label90.Location = new System.Drawing.Point(220, 338);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(2, 2);
            this.label90.TabIndex = 242;
            // 
            // label91
            // 
            this.label91.BackColor = System.Drawing.Color.White;
            this.label91.Location = new System.Drawing.Point(211, 338);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(2, 2);
            this.label91.TabIndex = 241;
            // 
            // label92
            // 
            this.label92.BackColor = System.Drawing.Color.White;
            this.label92.Location = new System.Drawing.Point(202, 338);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(2, 2);
            this.label92.TabIndex = 240;
            // 
            // label94
            // 
            this.label94.BackColor = System.Drawing.Color.White;
            this.label94.Location = new System.Drawing.Point(229, 338);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(2, 2);
            this.label94.TabIndex = 238;
            // 
            // label93
            // 
            this.label93.BackColor = System.Drawing.Color.White;
            this.label93.Location = new System.Drawing.Point(202, 356);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(2, 2);
            this.label93.TabIndex = 247;
            // 
            // label95
            // 
            this.label95.BackColor = System.Drawing.Color.White;
            this.label95.Location = new System.Drawing.Point(202, 374);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(2, 2);
            this.label95.TabIndex = 246;
            // 
            // label96
            // 
            this.label96.BackColor = System.Drawing.Color.White;
            this.label96.Location = new System.Drawing.Point(202, 365);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(2, 2);
            this.label96.TabIndex = 245;
            // 
            // label98
            // 
            this.label98.BackColor = System.Drawing.Color.White;
            this.label98.Location = new System.Drawing.Point(202, 347);
            this.label98.Name = "label98";
            this.label98.Size = new System.Drawing.Size(2, 2);
            this.label98.TabIndex = 243;
            // 
            // label97
            // 
            this.label97.BackColor = System.Drawing.Color.White;
            this.label97.Location = new System.Drawing.Point(334, 356);
            this.label97.Name = "label97";
            this.label97.Size = new System.Drawing.Size(2, 2);
            this.label97.TabIndex = 252;
            // 
            // label99
            // 
            this.label99.BackColor = System.Drawing.Color.White;
            this.label99.Location = new System.Drawing.Point(334, 374);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(2, 2);
            this.label99.TabIndex = 251;
            // 
            // label100
            // 
            this.label100.BackColor = System.Drawing.Color.White;
            this.label100.Location = new System.Drawing.Point(334, 365);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(2, 2);
            this.label100.TabIndex = 250;
            // 
            // label101
            // 
            this.label101.BackColor = System.Drawing.Color.White;
            this.label101.Location = new System.Drawing.Point(334, 347);
            this.label101.Name = "label101";
            this.label101.Size = new System.Drawing.Size(2, 2);
            this.label101.TabIndex = 249;
            // 
            // label102
            // 
            this.label102.BackColor = System.Drawing.Color.White;
            this.label102.Location = new System.Drawing.Point(334, 338);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(2, 2);
            this.label102.TabIndex = 248;
            // 
            // label103
            // 
            this.label103.BackColor = System.Drawing.Color.White;
            this.label103.Location = new System.Drawing.Point(326, 338);
            this.label103.Name = "label103";
            this.label103.Size = new System.Drawing.Size(2, 2);
            this.label103.TabIndex = 254;
            // 
            // label104
            // 
            this.label104.BackColor = System.Drawing.Color.White;
            this.label104.Location = new System.Drawing.Point(318, 338);
            this.label104.Name = "label104";
            this.label104.Size = new System.Drawing.Size(2, 2);
            this.label104.TabIndex = 253;
            // 
            // label105
            // 
            this.label105.BackColor = System.Drawing.Color.White;
            this.label105.Location = new System.Drawing.Point(326, 374);
            this.label105.Name = "label105";
            this.label105.Size = new System.Drawing.Size(2, 2);
            this.label105.TabIndex = 268;
            // 
            // label106
            // 
            this.label106.BackColor = System.Drawing.Color.White;
            this.label106.Location = new System.Drawing.Point(247, 374);
            this.label106.Name = "label106";
            this.label106.Size = new System.Drawing.Size(2, 2);
            this.label106.TabIndex = 267;
            // 
            // label107
            // 
            this.label107.BackColor = System.Drawing.Color.White;
            this.label107.Location = new System.Drawing.Point(238, 374);
            this.label107.Name = "label107";
            this.label107.Size = new System.Drawing.Size(2, 2);
            this.label107.TabIndex = 266;
            // 
            // label108
            // 
            this.label108.BackColor = System.Drawing.Color.White;
            this.label108.Location = new System.Drawing.Point(229, 374);
            this.label108.Name = "label108";
            this.label108.Size = new System.Drawing.Size(2, 2);
            this.label108.TabIndex = 265;
            // 
            // label109
            // 
            this.label109.BackColor = System.Drawing.Color.White;
            this.label109.Location = new System.Drawing.Point(220, 374);
            this.label109.Name = "label109";
            this.label109.Size = new System.Drawing.Size(2, 2);
            this.label109.TabIndex = 264;
            // 
            // label110
            // 
            this.label110.BackColor = System.Drawing.Color.White;
            this.label110.Location = new System.Drawing.Point(211, 374);
            this.label110.Name = "label110";
            this.label110.Size = new System.Drawing.Size(2, 2);
            this.label110.TabIndex = 263;
            // 
            // label111
            // 
            this.label111.BackColor = System.Drawing.Color.White;
            this.label111.Location = new System.Drawing.Point(318, 374);
            this.label111.Name = "label111";
            this.label111.Size = new System.Drawing.Size(2, 2);
            this.label111.TabIndex = 262;
            // 
            // label112
            // 
            this.label112.BackColor = System.Drawing.Color.White;
            this.label112.Location = new System.Drawing.Point(310, 374);
            this.label112.Name = "label112";
            this.label112.Size = new System.Drawing.Size(2, 2);
            this.label112.TabIndex = 261;
            // 
            // label113
            // 
            this.label113.BackColor = System.Drawing.Color.White;
            this.label113.Location = new System.Drawing.Point(301, 374);
            this.label113.Name = "label113";
            this.label113.Size = new System.Drawing.Size(2, 2);
            this.label113.TabIndex = 260;
            // 
            // label114
            // 
            this.label114.BackColor = System.Drawing.Color.White;
            this.label114.Location = new System.Drawing.Point(292, 374);
            this.label114.Name = "label114";
            this.label114.Size = new System.Drawing.Size(2, 2);
            this.label114.TabIndex = 259;
            // 
            // label115
            // 
            this.label115.BackColor = System.Drawing.Color.White;
            this.label115.Location = new System.Drawing.Point(283, 374);
            this.label115.Name = "label115";
            this.label115.Size = new System.Drawing.Size(2, 2);
            this.label115.TabIndex = 258;
            // 
            // label116
            // 
            this.label116.BackColor = System.Drawing.Color.White;
            this.label116.Location = new System.Drawing.Point(274, 374);
            this.label116.Name = "label116";
            this.label116.Size = new System.Drawing.Size(2, 2);
            this.label116.TabIndex = 257;
            // 
            // label117
            // 
            this.label117.BackColor = System.Drawing.Color.White;
            this.label117.Location = new System.Drawing.Point(265, 374);
            this.label117.Name = "label117";
            this.label117.Size = new System.Drawing.Size(2, 2);
            this.label117.TabIndex = 256;
            // 
            // label118
            // 
            this.label118.BackColor = System.Drawing.Color.White;
            this.label118.Location = new System.Drawing.Point(256, 374);
            this.label118.Name = "label118";
            this.label118.Size = new System.Drawing.Size(2, 2);
            this.label118.TabIndex = 255;
            // 
            // label119
            // 
            this.label119.BackColor = System.Drawing.Color.White;
            this.label119.Location = new System.Drawing.Point(157, 374);
            this.label119.Name = "label119";
            this.label119.Size = new System.Drawing.Size(2, 2);
            this.label119.TabIndex = 312;
            // 
            // label120
            // 
            this.label120.BackColor = System.Drawing.Color.White;
            this.label120.Location = new System.Drawing.Point(78, 374);
            this.label120.Name = "label120";
            this.label120.Size = new System.Drawing.Size(2, 2);
            this.label120.TabIndex = 311;
            // 
            // label121
            // 
            this.label121.BackColor = System.Drawing.Color.White;
            this.label121.Location = new System.Drawing.Point(69, 374);
            this.label121.Name = "label121";
            this.label121.Size = new System.Drawing.Size(2, 2);
            this.label121.TabIndex = 310;
            // 
            // label122
            // 
            this.label122.BackColor = System.Drawing.Color.White;
            this.label122.Location = new System.Drawing.Point(60, 374);
            this.label122.Name = "label122";
            this.label122.Size = new System.Drawing.Size(2, 2);
            this.label122.TabIndex = 309;
            // 
            // label123
            // 
            this.label123.BackColor = System.Drawing.Color.White;
            this.label123.Location = new System.Drawing.Point(51, 374);
            this.label123.Name = "label123";
            this.label123.Size = new System.Drawing.Size(2, 2);
            this.label123.TabIndex = 308;
            // 
            // label125
            // 
            this.label125.BackColor = System.Drawing.Color.White;
            this.label125.Location = new System.Drawing.Point(149, 374);
            this.label125.Name = "label125";
            this.label125.Size = new System.Drawing.Size(2, 2);
            this.label125.TabIndex = 306;
            // 
            // label126
            // 
            this.label126.BackColor = System.Drawing.Color.White;
            this.label126.Location = new System.Drawing.Point(141, 374);
            this.label126.Name = "label126";
            this.label126.Size = new System.Drawing.Size(2, 2);
            this.label126.TabIndex = 305;
            // 
            // label127
            // 
            this.label127.BackColor = System.Drawing.Color.White;
            this.label127.Location = new System.Drawing.Point(132, 374);
            this.label127.Name = "label127";
            this.label127.Size = new System.Drawing.Size(2, 2);
            this.label127.TabIndex = 304;
            // 
            // label128
            // 
            this.label128.BackColor = System.Drawing.Color.White;
            this.label128.Location = new System.Drawing.Point(123, 374);
            this.label128.Name = "label128";
            this.label128.Size = new System.Drawing.Size(2, 2);
            this.label128.TabIndex = 303;
            // 
            // label129
            // 
            this.label129.BackColor = System.Drawing.Color.White;
            this.label129.Location = new System.Drawing.Point(114, 374);
            this.label129.Name = "label129";
            this.label129.Size = new System.Drawing.Size(2, 2);
            this.label129.TabIndex = 302;
            // 
            // label130
            // 
            this.label130.BackColor = System.Drawing.Color.White;
            this.label130.Location = new System.Drawing.Point(105, 374);
            this.label130.Name = "label130";
            this.label130.Size = new System.Drawing.Size(2, 2);
            this.label130.TabIndex = 301;
            // 
            // label131
            // 
            this.label131.BackColor = System.Drawing.Color.White;
            this.label131.Location = new System.Drawing.Point(96, 374);
            this.label131.Name = "label131";
            this.label131.Size = new System.Drawing.Size(2, 2);
            this.label131.TabIndex = 300;
            // 
            // label132
            // 
            this.label132.BackColor = System.Drawing.Color.White;
            this.label132.Location = new System.Drawing.Point(87, 374);
            this.label132.Name = "label132";
            this.label132.Size = new System.Drawing.Size(2, 2);
            this.label132.TabIndex = 299;
            // 
            // label133
            // 
            this.label133.BackColor = System.Drawing.Color.White;
            this.label133.Location = new System.Drawing.Point(156, 338);
            this.label133.Name = "label133";
            this.label133.Size = new System.Drawing.Size(2, 2);
            this.label133.TabIndex = 298;
            // 
            // label134
            // 
            this.label134.BackColor = System.Drawing.Color.White;
            this.label134.Location = new System.Drawing.Point(147, 338);
            this.label134.Name = "label134";
            this.label134.Size = new System.Drawing.Size(2, 2);
            this.label134.TabIndex = 297;
            // 
            // label135
            // 
            this.label135.BackColor = System.Drawing.Color.White;
            this.label135.Location = new System.Drawing.Point(165, 356);
            this.label135.Name = "label135";
            this.label135.Size = new System.Drawing.Size(2, 2);
            this.label135.TabIndex = 296;
            // 
            // label136
            // 
            this.label136.BackColor = System.Drawing.Color.White;
            this.label136.Location = new System.Drawing.Point(165, 374);
            this.label136.Name = "label136";
            this.label136.Size = new System.Drawing.Size(2, 2);
            this.label136.TabIndex = 295;
            // 
            // label137
            // 
            this.label137.BackColor = System.Drawing.Color.White;
            this.label137.Location = new System.Drawing.Point(165, 365);
            this.label137.Name = "label137";
            this.label137.Size = new System.Drawing.Size(2, 2);
            this.label137.TabIndex = 294;
            // 
            // label138
            // 
            this.label138.BackColor = System.Drawing.Color.White;
            this.label138.Location = new System.Drawing.Point(165, 347);
            this.label138.Name = "label138";
            this.label138.Size = new System.Drawing.Size(2, 2);
            this.label138.TabIndex = 293;
            // 
            // label139
            // 
            this.label139.BackColor = System.Drawing.Color.White;
            this.label139.Location = new System.Drawing.Point(165, 338);
            this.label139.Name = "label139";
            this.label139.Size = new System.Drawing.Size(2, 2);
            this.label139.TabIndex = 292;
            // 
            // label140
            // 
            this.label140.BackColor = System.Drawing.Color.White;
            this.label140.Location = new System.Drawing.Point(35, 356);
            this.label140.Name = "label140";
            this.label140.Size = new System.Drawing.Size(2, 2);
            this.label140.TabIndex = 291;
            // 
            // label143
            // 
            this.label143.BackColor = System.Drawing.Color.White;
            this.label143.Location = new System.Drawing.Point(35, 347);
            this.label143.Name = "label143";
            this.label143.Size = new System.Drawing.Size(2, 2);
            this.label143.TabIndex = 288;
            // 
            // label144
            // 
            this.label144.BackColor = System.Drawing.Color.White;
            this.label144.Location = new System.Drawing.Point(50, 338);
            this.label144.Name = "label144";
            this.label144.Size = new System.Drawing.Size(2, 2);
            this.label144.TabIndex = 287;
            // 
            // label145
            // 
            this.label145.BackColor = System.Drawing.Color.White;
            this.label145.Location = new System.Drawing.Point(42, 338);
            this.label145.Name = "label145";
            this.label145.Size = new System.Drawing.Size(2, 2);
            this.label145.TabIndex = 286;
            // 
            // label146
            // 
            this.label146.BackColor = System.Drawing.Color.White;
            this.label146.Location = new System.Drawing.Point(35, 338);
            this.label146.Name = "label146";
            this.label146.Size = new System.Drawing.Size(2, 2);
            this.label146.TabIndex = 285;
            // 
            // label147
            // 
            this.label147.BackColor = System.Drawing.Color.White;
            this.label147.Location = new System.Drawing.Point(59, 338);
            this.label147.Name = "label147";
            this.label147.Size = new System.Drawing.Size(2, 2);
            this.label147.TabIndex = 284;
            // 
            // label148
            // 
            this.label148.BackColor = System.Drawing.Color.White;
            this.label148.Location = new System.Drawing.Point(59, 311);
            this.label148.Name = "label148";
            this.label148.Size = new System.Drawing.Size(2, 2);
            this.label148.TabIndex = 283;
            // 
            // label149
            // 
            this.label149.BackColor = System.Drawing.Color.White;
            this.label149.Location = new System.Drawing.Point(59, 329);
            this.label149.Name = "label149";
            this.label149.Size = new System.Drawing.Size(2, 2);
            this.label149.TabIndex = 282;
            // 
            // label150
            // 
            this.label150.BackColor = System.Drawing.Color.White;
            this.label150.Location = new System.Drawing.Point(59, 320);
            this.label150.Name = "label150";
            this.label150.Size = new System.Drawing.Size(2, 2);
            this.label150.TabIndex = 281;
            // 
            // label151
            // 
            this.label151.BackColor = System.Drawing.Color.White;
            this.label151.Location = new System.Drawing.Point(68, 338);
            this.label151.Name = "label151";
            this.label151.Size = new System.Drawing.Size(2, 2);
            this.label151.TabIndex = 280;
            // 
            // label152
            // 
            this.label152.BackColor = System.Drawing.Color.White;
            this.label152.Location = new System.Drawing.Point(94, 311);
            this.label152.Name = "label152";
            this.label152.Size = new System.Drawing.Size(2, 2);
            this.label152.TabIndex = 279;
            // 
            // label153
            // 
            this.label153.BackColor = System.Drawing.Color.White;
            this.label153.Location = new System.Drawing.Point(94, 329);
            this.label153.Name = "label153";
            this.label153.Size = new System.Drawing.Size(2, 2);
            this.label153.TabIndex = 278;
            // 
            // label154
            // 
            this.label154.BackColor = System.Drawing.Color.White;
            this.label154.Location = new System.Drawing.Point(94, 320);
            this.label154.Name = "label154";
            this.label154.Size = new System.Drawing.Size(2, 2);
            this.label154.TabIndex = 277;
            // 
            // label155
            // 
            this.label155.BackColor = System.Drawing.Color.White;
            this.label155.Location = new System.Drawing.Point(129, 338);
            this.label155.Name = "label155";
            this.label155.Size = new System.Drawing.Size(2, 2);
            this.label155.TabIndex = 276;
            // 
            // label156
            // 
            this.label156.BackColor = System.Drawing.Color.White;
            this.label156.Location = new System.Drawing.Point(94, 338);
            this.label156.Name = "label156";
            this.label156.Size = new System.Drawing.Size(2, 2);
            this.label156.TabIndex = 275;
            // 
            // label157
            // 
            this.label157.BackColor = System.Drawing.Color.White;
            this.label157.Location = new System.Drawing.Point(85, 338);
            this.label157.Name = "label157";
            this.label157.Size = new System.Drawing.Size(2, 2);
            this.label157.TabIndex = 274;
            // 
            // label158
            // 
            this.label158.BackColor = System.Drawing.Color.White;
            this.label158.Location = new System.Drawing.Point(76, 338);
            this.label158.Name = "label158";
            this.label158.Size = new System.Drawing.Size(2, 2);
            this.label158.TabIndex = 273;
            // 
            // label159
            // 
            this.label159.BackColor = System.Drawing.Color.White;
            this.label159.Location = new System.Drawing.Point(129, 311);
            this.label159.Name = "label159";
            this.label159.Size = new System.Drawing.Size(2, 2);
            this.label159.TabIndex = 272;
            // 
            // label160
            // 
            this.label160.BackColor = System.Drawing.Color.White;
            this.label160.Location = new System.Drawing.Point(138, 338);
            this.label160.Name = "label160";
            this.label160.Size = new System.Drawing.Size(2, 2);
            this.label160.TabIndex = 271;
            // 
            // label161
            // 
            this.label161.BackColor = System.Drawing.Color.White;
            this.label161.Location = new System.Drawing.Point(129, 329);
            this.label161.Name = "label161";
            this.label161.Size = new System.Drawing.Size(2, 2);
            this.label161.TabIndex = 270;
            // 
            // label162
            // 
            this.label162.BackColor = System.Drawing.Color.White;
            this.label162.Location = new System.Drawing.Point(129, 320);
            this.label162.Name = "label162";
            this.label162.Size = new System.Drawing.Size(2, 2);
            this.label162.TabIndex = 269;
            // 
            // label163
            // 
            this.label163.BackColor = System.Drawing.Color.White;
            this.label163.Location = new System.Drawing.Point(192, 374);
            this.label163.Name = "label163";
            this.label163.Size = new System.Drawing.Size(2, 2);
            this.label163.TabIndex = 315;
            // 
            // label164
            // 
            this.label164.BackColor = System.Drawing.Color.White;
            this.label164.Location = new System.Drawing.Point(183, 374);
            this.label164.Name = "label164";
            this.label164.Size = new System.Drawing.Size(2, 2);
            this.label164.TabIndex = 314;
            // 
            // label165
            // 
            this.label165.BackColor = System.Drawing.Color.White;
            this.label165.Location = new System.Drawing.Point(174, 374);
            this.label165.Name = "label165";
            this.label165.Size = new System.Drawing.Size(2, 2);
            this.label165.TabIndex = 313;
            // 
            // label166
            // 
            this.label166.BackColor = System.Drawing.Color.White;
            this.label166.Location = new System.Drawing.Point(35, 293);
            this.label166.Name = "label166";
            this.label166.Size = new System.Drawing.Size(2, 2);
            this.label166.TabIndex = 318;
            // 
            // label167
            // 
            this.label167.BackColor = System.Drawing.Color.White;
            this.label167.Location = new System.Drawing.Point(35, 284);
            this.label167.Name = "label167";
            this.label167.Size = new System.Drawing.Size(2, 2);
            this.label167.TabIndex = 317;
            // 
            // label168
            // 
            this.label168.BackColor = System.Drawing.Color.White;
            this.label168.Location = new System.Drawing.Point(35, 275);
            this.label168.Name = "label168";
            this.label168.Size = new System.Drawing.Size(2, 2);
            this.label168.TabIndex = 316;
            // 
            // label169
            // 
            this.label169.BackColor = System.Drawing.Color.White;
            this.label169.Location = new System.Drawing.Point(86, 266);
            this.label169.Name = "label169";
            this.label169.Size = new System.Drawing.Size(2, 2);
            this.label169.TabIndex = 319;
            // 
            // label170
            // 
            this.label170.BackColor = System.Drawing.Color.White;
            this.label170.Location = new System.Drawing.Point(59, 302);
            this.label170.Name = "label170";
            this.label170.Size = new System.Drawing.Size(2, 2);
            this.label170.TabIndex = 323;
            // 
            // label171
            // 
            this.label171.BackColor = System.Drawing.Color.White;
            this.label171.Location = new System.Drawing.Point(51, 302);
            this.label171.Name = "label171";
            this.label171.Size = new System.Drawing.Size(2, 2);
            this.label171.TabIndex = 322;
            // 
            // label172
            // 
            this.label172.BackColor = System.Drawing.Color.White;
            this.label172.Location = new System.Drawing.Point(43, 302);
            this.label172.Name = "label172";
            this.label172.Size = new System.Drawing.Size(2, 2);
            this.label172.TabIndex = 321;
            // 
            // label173
            // 
            this.label173.BackColor = System.Drawing.Color.Black;
            this.label173.Image = ((System.Drawing.Image)(resources.GetObject("label173.Image")));
            this.label173.Location = new System.Drawing.Point(31, 298);
            this.label173.Name = "label173";
            this.label173.Size = new System.Drawing.Size(10, 10);
            this.label173.TabIndex = 320;
            // 
            // label174
            // 
            this.label174.BackColor = System.Drawing.Color.White;
            this.label174.Location = new System.Drawing.Point(274, 230);
            this.label174.Name = "label174";
            this.label174.Size = new System.Drawing.Size(2, 2);
            this.label174.TabIndex = 333;
            // 
            // label175
            // 
            this.label175.BackColor = System.Drawing.Color.White;
            this.label175.Location = new System.Drawing.Point(274, 248);
            this.label175.Name = "label175";
            this.label175.Size = new System.Drawing.Size(2, 2);
            this.label175.TabIndex = 332;
            // 
            // label176
            // 
            this.label176.BackColor = System.Drawing.Color.White;
            this.label176.Location = new System.Drawing.Point(274, 239);
            this.label176.Name = "label176";
            this.label176.Size = new System.Drawing.Size(2, 2);
            this.label176.TabIndex = 331;
            // 
            // label177
            // 
            this.label177.BackColor = System.Drawing.Color.White;
            this.label177.Location = new System.Drawing.Point(274, 257);
            this.label177.Name = "label177";
            this.label177.Size = new System.Drawing.Size(2, 2);
            this.label177.TabIndex = 330;
            // 
            // label178
            // 
            this.label178.BackColor = System.Drawing.Color.White;
            this.label178.Location = new System.Drawing.Point(274, 212);
            this.label178.Name = "label178";
            this.label178.Size = new System.Drawing.Size(2, 2);
            this.label178.TabIndex = 329;
            // 
            // label179
            // 
            this.label179.BackColor = System.Drawing.Color.White;
            this.label179.Location = new System.Drawing.Point(274, 203);
            this.label179.Name = "label179";
            this.label179.Size = new System.Drawing.Size(2, 2);
            this.label179.TabIndex = 328;
            // 
            // label180
            // 
            this.label180.BackColor = System.Drawing.Color.White;
            this.label180.Location = new System.Drawing.Point(274, 194);
            this.label180.Name = "label180";
            this.label180.Size = new System.Drawing.Size(2, 2);
            this.label180.TabIndex = 327;
            // 
            // label181
            // 
            this.label181.BackColor = System.Drawing.Color.White;
            this.label181.Location = new System.Drawing.Point(274, 221);
            this.label181.Name = "label181";
            this.label181.Size = new System.Drawing.Size(2, 2);
            this.label181.TabIndex = 326;
            // 
            // label182
            // 
            this.label182.BackColor = System.Drawing.Color.White;
            this.label182.Location = new System.Drawing.Point(274, 185);
            this.label182.Name = "label182";
            this.label182.Size = new System.Drawing.Size(2, 2);
            this.label182.TabIndex = 325;
            // 
            // label183
            // 
            this.label183.BackColor = System.Drawing.Color.White;
            this.label183.Location = new System.Drawing.Point(274, 149);
            this.label183.Name = "label183";
            this.label183.Size = new System.Drawing.Size(2, 2);
            this.label183.TabIndex = 342;
            // 
            // label184
            // 
            this.label184.BackColor = System.Drawing.Color.White;
            this.label184.Location = new System.Drawing.Point(274, 167);
            this.label184.Name = "label184";
            this.label184.Size = new System.Drawing.Size(2, 2);
            this.label184.TabIndex = 341;
            // 
            // label185
            // 
            this.label185.BackColor = System.Drawing.Color.White;
            this.label185.Location = new System.Drawing.Point(274, 158);
            this.label185.Name = "label185";
            this.label185.Size = new System.Drawing.Size(2, 2);
            this.label185.TabIndex = 340;
            // 
            // label186
            // 
            this.label186.BackColor = System.Drawing.Color.White;
            this.label186.Location = new System.Drawing.Point(274, 176);
            this.label186.Name = "label186";
            this.label186.Size = new System.Drawing.Size(2, 2);
            this.label186.TabIndex = 339;
            // 
            // label187
            // 
            this.label187.BackColor = System.Drawing.Color.White;
            this.label187.Location = new System.Drawing.Point(274, 131);
            this.label187.Name = "label187";
            this.label187.Size = new System.Drawing.Size(2, 2);
            this.label187.TabIndex = 338;
            // 
            // label188
            // 
            this.label188.BackColor = System.Drawing.Color.White;
            this.label188.Location = new System.Drawing.Point(274, 122);
            this.label188.Name = "label188";
            this.label188.Size = new System.Drawing.Size(2, 2);
            this.label188.TabIndex = 337;
            // 
            // label189
            // 
            this.label189.BackColor = System.Drawing.Color.White;
            this.label189.Location = new System.Drawing.Point(274, 113);
            this.label189.Name = "label189";
            this.label189.Size = new System.Drawing.Size(2, 2);
            this.label189.TabIndex = 336;
            // 
            // label190
            // 
            this.label190.BackColor = System.Drawing.Color.White;
            this.label190.Location = new System.Drawing.Point(274, 140);
            this.label190.Name = "label190";
            this.label190.Size = new System.Drawing.Size(2, 2);
            this.label190.TabIndex = 335;
            // 
            // label191
            // 
            this.label191.BackColor = System.Drawing.Color.White;
            this.label191.Location = new System.Drawing.Point(274, 104);
            this.label191.Name = "label191";
            this.label191.Size = new System.Drawing.Size(2, 2);
            this.label191.TabIndex = 334;
            // 
            // label192
            // 
            this.label192.BackColor = System.Drawing.Color.White;
            this.label192.Location = new System.Drawing.Point(274, 66);
            this.label192.Name = "label192";
            this.label192.Size = new System.Drawing.Size(2, 2);
            this.label192.TabIndex = 351;
            // 
            // label193
            // 
            this.label193.BackColor = System.Drawing.Color.White;
            this.label193.Location = new System.Drawing.Point(274, 85);
            this.label193.Name = "label193";
            this.label193.Size = new System.Drawing.Size(2, 2);
            this.label193.TabIndex = 350;
            // 
            // label194
            // 
            this.label194.BackColor = System.Drawing.Color.White;
            this.label194.Location = new System.Drawing.Point(274, 76);
            this.label194.Name = "label194";
            this.label194.Size = new System.Drawing.Size(2, 2);
            this.label194.TabIndex = 349;
            // 
            // label195
            // 
            this.label195.BackColor = System.Drawing.Color.White;
            this.label195.Location = new System.Drawing.Point(274, 94);
            this.label195.Name = "label195";
            this.label195.Size = new System.Drawing.Size(2, 2);
            this.label195.TabIndex = 348;
            // 
            // label196
            // 
            this.label196.BackColor = System.Drawing.Color.White;
            this.label196.Location = new System.Drawing.Point(274, 47);
            this.label196.Name = "label196";
            this.label196.Size = new System.Drawing.Size(2, 2);
            this.label196.TabIndex = 347;
            // 
            // label199
            // 
            this.label199.BackColor = System.Drawing.Color.White;
            this.label199.Location = new System.Drawing.Point(274, 57);
            this.label199.Name = "label199";
            this.label199.Size = new System.Drawing.Size(2, 2);
            this.label199.TabIndex = 344;
            // 
            // label198
            // 
            this.label198.BackColor = System.Drawing.Color.White;
            this.label198.Location = new System.Drawing.Point(334, 38);
            this.label198.Name = "label198";
            this.label198.Size = new System.Drawing.Size(2, 2);
            this.label198.TabIndex = 367;
            // 
            // label200
            // 
            this.label200.BackColor = System.Drawing.Color.White;
            this.label200.Location = new System.Drawing.Point(326, 38);
            this.label200.Name = "label200";
            this.label200.Size = new System.Drawing.Size(2, 2);
            this.label200.TabIndex = 366;
            // 
            // label201
            // 
            this.label201.BackColor = System.Drawing.Color.White;
            this.label201.Location = new System.Drawing.Point(247, 38);
            this.label201.Name = "label201";
            this.label201.Size = new System.Drawing.Size(2, 2);
            this.label201.TabIndex = 365;
            // 
            // label202
            // 
            this.label202.BackColor = System.Drawing.Color.White;
            this.label202.Location = new System.Drawing.Point(238, 38);
            this.label202.Name = "label202";
            this.label202.Size = new System.Drawing.Size(2, 2);
            this.label202.TabIndex = 364;
            // 
            // label203
            // 
            this.label203.BackColor = System.Drawing.Color.White;
            this.label203.Location = new System.Drawing.Point(229, 38);
            this.label203.Name = "label203";
            this.label203.Size = new System.Drawing.Size(2, 2);
            this.label203.TabIndex = 363;
            // 
            // label204
            // 
            this.label204.BackColor = System.Drawing.Color.White;
            this.label204.Location = new System.Drawing.Point(220, 38);
            this.label204.Name = "label204";
            this.label204.Size = new System.Drawing.Size(2, 2);
            this.label204.TabIndex = 362;
            // 
            // label205
            // 
            this.label205.BackColor = System.Drawing.Color.White;
            this.label205.Location = new System.Drawing.Point(211, 38);
            this.label205.Name = "label205";
            this.label205.Size = new System.Drawing.Size(2, 2);
            this.label205.TabIndex = 361;
            // 
            // label206
            // 
            this.label206.BackColor = System.Drawing.Color.White;
            this.label206.Location = new System.Drawing.Point(202, 38);
            this.label206.Name = "label206";
            this.label206.Size = new System.Drawing.Size(2, 2);
            this.label206.TabIndex = 360;
            // 
            // label207
            // 
            this.label207.BackColor = System.Drawing.Color.White;
            this.label207.Location = new System.Drawing.Point(318, 38);
            this.label207.Name = "label207";
            this.label207.Size = new System.Drawing.Size(2, 2);
            this.label207.TabIndex = 359;
            // 
            // label208
            // 
            this.label208.BackColor = System.Drawing.Color.White;
            this.label208.Location = new System.Drawing.Point(310, 38);
            this.label208.Name = "label208";
            this.label208.Size = new System.Drawing.Size(2, 2);
            this.label208.TabIndex = 358;
            // 
            // label209
            // 
            this.label209.BackColor = System.Drawing.Color.White;
            this.label209.Location = new System.Drawing.Point(301, 38);
            this.label209.Name = "label209";
            this.label209.Size = new System.Drawing.Size(2, 2);
            this.label209.TabIndex = 357;
            // 
            // label210
            // 
            this.label210.BackColor = System.Drawing.Color.White;
            this.label210.Location = new System.Drawing.Point(292, 38);
            this.label210.Name = "label210";
            this.label210.Size = new System.Drawing.Size(2, 2);
            this.label210.TabIndex = 356;
            // 
            // label211
            // 
            this.label211.BackColor = System.Drawing.Color.White;
            this.label211.Location = new System.Drawing.Point(283, 38);
            this.label211.Name = "label211";
            this.label211.Size = new System.Drawing.Size(2, 2);
            this.label211.TabIndex = 355;
            // 
            // label212
            // 
            this.label212.BackColor = System.Drawing.Color.White;
            this.label212.Location = new System.Drawing.Point(274, 38);
            this.label212.Name = "label212";
            this.label212.Size = new System.Drawing.Size(2, 2);
            this.label212.TabIndex = 354;
            // 
            // label213
            // 
            this.label213.BackColor = System.Drawing.Color.White;
            this.label213.Location = new System.Drawing.Point(265, 38);
            this.label213.Name = "label213";
            this.label213.Size = new System.Drawing.Size(2, 2);
            this.label213.TabIndex = 353;
            // 
            // label214
            // 
            this.label214.BackColor = System.Drawing.Color.White;
            this.label214.Location = new System.Drawing.Point(256, 38);
            this.label214.Name = "label214";
            this.label214.Size = new System.Drawing.Size(2, 2);
            this.label214.TabIndex = 352;
            // 
            // label197
            // 
            this.label197.BackColor = System.Drawing.Color.White;
            this.label197.Location = new System.Drawing.Point(334, 94);
            this.label197.Name = "label197";
            this.label197.Size = new System.Drawing.Size(2, 2);
            this.label197.TabIndex = 376;
            // 
            // label215
            // 
            this.label215.BackColor = System.Drawing.Color.White;
            this.label215.Location = new System.Drawing.Point(334, 113);
            this.label215.Name = "label215";
            this.label215.Size = new System.Drawing.Size(2, 2);
            this.label215.TabIndex = 375;
            // 
            // label216
            // 
            this.label216.BackColor = System.Drawing.Color.White;
            this.label216.Location = new System.Drawing.Point(334, 104);
            this.label216.Name = "label216";
            this.label216.Size = new System.Drawing.Size(2, 2);
            this.label216.TabIndex = 374;
            // 
            // label217
            // 
            this.label217.BackColor = System.Drawing.Color.White;
            this.label217.Location = new System.Drawing.Point(334, 122);
            this.label217.Name = "label217";
            this.label217.Size = new System.Drawing.Size(2, 2);
            this.label217.TabIndex = 373;
            // 
            // label218
            // 
            this.label218.BackColor = System.Drawing.Color.White;
            this.label218.Location = new System.Drawing.Point(334, 76);
            this.label218.Name = "label218";
            this.label218.Size = new System.Drawing.Size(2, 2);
            this.label218.TabIndex = 372;
            // 
            // label219
            // 
            this.label219.BackColor = System.Drawing.Color.White;
            this.label219.Location = new System.Drawing.Point(334, 67);
            this.label219.Name = "label219";
            this.label219.Size = new System.Drawing.Size(2, 2);
            this.label219.TabIndex = 371;
            // 
            // label220
            // 
            this.label220.BackColor = System.Drawing.Color.Black;
            this.label220.Image = ((System.Drawing.Image)(resources.GetObject("label220.Image")));
            this.label220.Location = new System.Drawing.Point(330, 54);
            this.label220.Name = "label220";
            this.label220.Size = new System.Drawing.Size(10, 10);
            this.label220.TabIndex = 370;
            // 
            // label221
            // 
            this.label221.BackColor = System.Drawing.Color.White;
            this.label221.Location = new System.Drawing.Point(334, 85);
            this.label221.Name = "label221";
            this.label221.Size = new System.Drawing.Size(2, 2);
            this.label221.TabIndex = 369;
            // 
            // label222
            // 
            this.label222.BackColor = System.Drawing.Color.White;
            this.label222.Location = new System.Drawing.Point(334, 48);
            this.label222.Name = "label222";
            this.label222.Size = new System.Drawing.Size(2, 2);
            this.label222.TabIndex = 368;
            // 
            // label223
            // 
            this.label223.BackColor = System.Drawing.Color.White;
            this.label223.Location = new System.Drawing.Point(326, 85);
            this.label223.Name = "label223";
            this.label223.Size = new System.Drawing.Size(2, 2);
            this.label223.TabIndex = 382;
            // 
            // label224
            // 
            this.label224.BackColor = System.Drawing.Color.White;
            this.label224.Location = new System.Drawing.Point(318, 85);
            this.label224.Name = "label224";
            this.label224.Size = new System.Drawing.Size(2, 2);
            this.label224.TabIndex = 381;
            // 
            // label225
            // 
            this.label225.BackColor = System.Drawing.Color.White;
            this.label225.Location = new System.Drawing.Point(310, 85);
            this.label225.Name = "label225";
            this.label225.Size = new System.Drawing.Size(2, 2);
            this.label225.TabIndex = 380;
            // 
            // label226
            // 
            this.label226.BackColor = System.Drawing.Color.White;
            this.label226.Location = new System.Drawing.Point(301, 85);
            this.label226.Name = "label226";
            this.label226.Size = new System.Drawing.Size(2, 2);
            this.label226.TabIndex = 379;
            // 
            // label227
            // 
            this.label227.BackColor = System.Drawing.Color.White;
            this.label227.Location = new System.Drawing.Point(292, 85);
            this.label227.Name = "label227";
            this.label227.Size = new System.Drawing.Size(2, 2);
            this.label227.TabIndex = 378;
            // 
            // label228
            // 
            this.label228.BackColor = System.Drawing.Color.White;
            this.label228.Location = new System.Drawing.Point(283, 85);
            this.label228.Name = "label228";
            this.label228.Size = new System.Drawing.Size(2, 2);
            this.label228.TabIndex = 377;
            // 
            // label229
            // 
            this.label229.BackColor = System.Drawing.Color.White;
            this.label229.Location = new System.Drawing.Point(326, 122);
            this.label229.Name = "label229";
            this.label229.Size = new System.Drawing.Size(2, 2);
            this.label229.TabIndex = 388;
            // 
            // label230
            // 
            this.label230.BackColor = System.Drawing.Color.White;
            this.label230.Location = new System.Drawing.Point(318, 122);
            this.label230.Name = "label230";
            this.label230.Size = new System.Drawing.Size(2, 2);
            this.label230.TabIndex = 387;
            // 
            // label231
            // 
            this.label231.BackColor = System.Drawing.Color.White;
            this.label231.Location = new System.Drawing.Point(310, 122);
            this.label231.Name = "label231";
            this.label231.Size = new System.Drawing.Size(2, 2);
            this.label231.TabIndex = 386;
            // 
            // label232
            // 
            this.label232.BackColor = System.Drawing.Color.White;
            this.label232.Location = new System.Drawing.Point(301, 122);
            this.label232.Name = "label232";
            this.label232.Size = new System.Drawing.Size(2, 2);
            this.label232.TabIndex = 385;
            // 
            // label233
            // 
            this.label233.BackColor = System.Drawing.Color.White;
            this.label233.Location = new System.Drawing.Point(292, 122);
            this.label233.Name = "label233";
            this.label233.Size = new System.Drawing.Size(2, 2);
            this.label233.TabIndex = 384;
            // 
            // label234
            // 
            this.label234.BackColor = System.Drawing.Color.White;
            this.label234.Location = new System.Drawing.Point(283, 122);
            this.label234.Name = "label234";
            this.label234.Size = new System.Drawing.Size(2, 2);
            this.label234.TabIndex = 383;
            // 
            // label235
            // 
            this.label235.BackColor = System.Drawing.Color.White;
            this.label235.Location = new System.Drawing.Point(247, 85);
            this.label235.Name = "label235";
            this.label235.Size = new System.Drawing.Size(2, 2);
            this.label235.TabIndex = 396;
            // 
            // label236
            // 
            this.label236.BackColor = System.Drawing.Color.White;
            this.label236.Location = new System.Drawing.Point(238, 85);
            this.label236.Name = "label236";
            this.label236.Size = new System.Drawing.Size(2, 2);
            this.label236.TabIndex = 395;
            // 
            // label237
            // 
            this.label237.BackColor = System.Drawing.Color.White;
            this.label237.Location = new System.Drawing.Point(229, 85);
            this.label237.Name = "label237";
            this.label237.Size = new System.Drawing.Size(2, 2);
            this.label237.TabIndex = 394;
            // 
            // label238
            // 
            this.label238.BackColor = System.Drawing.Color.White;
            this.label238.Location = new System.Drawing.Point(220, 85);
            this.label238.Name = "label238";
            this.label238.Size = new System.Drawing.Size(2, 2);
            this.label238.TabIndex = 393;
            // 
            // label239
            // 
            this.label239.BackColor = System.Drawing.Color.White;
            this.label239.Location = new System.Drawing.Point(211, 85);
            this.label239.Name = "label239";
            this.label239.Size = new System.Drawing.Size(2, 2);
            this.label239.TabIndex = 392;
            // 
            // label240
            // 
            this.label240.BackColor = System.Drawing.Color.White;
            this.label240.Location = new System.Drawing.Point(202, 85);
            this.label240.Name = "label240";
            this.label240.Size = new System.Drawing.Size(2, 2);
            this.label240.TabIndex = 391;
            // 
            // label241
            // 
            this.label241.BackColor = System.Drawing.Color.White;
            this.label241.Location = new System.Drawing.Point(265, 85);
            this.label241.Name = "label241";
            this.label241.Size = new System.Drawing.Size(2, 2);
            this.label241.TabIndex = 390;
            // 
            // label242
            // 
            this.label242.BackColor = System.Drawing.Color.White;
            this.label242.Location = new System.Drawing.Point(256, 85);
            this.label242.Name = "label242";
            this.label242.Size = new System.Drawing.Size(2, 2);
            this.label242.TabIndex = 389;
            // 
            // label243
            // 
            this.label243.BackColor = System.Drawing.Color.White;
            this.label243.Location = new System.Drawing.Point(202, 66);
            this.label243.Name = "label243";
            this.label243.Size = new System.Drawing.Size(2, 2);
            this.label243.TabIndex = 400;
            // 
            // label244
            // 
            this.label244.BackColor = System.Drawing.Color.White;
            this.label244.Location = new System.Drawing.Point(202, 76);
            this.label244.Name = "label244";
            this.label244.Size = new System.Drawing.Size(2, 2);
            this.label244.TabIndex = 399;
            // 
            // label245
            // 
            this.label245.BackColor = System.Drawing.Color.White;
            this.label245.Location = new System.Drawing.Point(202, 47);
            this.label245.Name = "label245";
            this.label245.Size = new System.Drawing.Size(2, 2);
            this.label245.TabIndex = 398;
            // 
            // label246
            // 
            this.label246.BackColor = System.Drawing.Color.White;
            this.label246.Location = new System.Drawing.Point(202, 57);
            this.label246.Name = "label246";
            this.label246.Size = new System.Drawing.Size(2, 2);
            this.label246.TabIndex = 397;
            // 
            // label247
            // 
            this.label247.BackColor = System.Drawing.Color.White;
            this.label247.Location = new System.Drawing.Point(129, 94);
            this.label247.Name = "label247";
            this.label247.Size = new System.Drawing.Size(2, 2);
            this.label247.TabIndex = 419;
            // 
            // label248
            // 
            this.label248.BackColor = System.Drawing.Color.White;
            this.label248.Location = new System.Drawing.Point(129, 112);
            this.label248.Name = "label248";
            this.label248.Size = new System.Drawing.Size(2, 2);
            this.label248.TabIndex = 418;
            // 
            // label249
            // 
            this.label249.BackColor = System.Drawing.Color.White;
            this.label249.Location = new System.Drawing.Point(129, 103);
            this.label249.Name = "label249";
            this.label249.Size = new System.Drawing.Size(2, 2);
            this.label249.TabIndex = 417;
            // 
            // label250
            // 
            this.label250.BackColor = System.Drawing.Color.White;
            this.label250.Location = new System.Drawing.Point(238, 94);
            this.label250.Name = "label250";
            this.label250.Size = new System.Drawing.Size(2, 2);
            this.label250.TabIndex = 416;
            // 
            // label251
            // 
            this.label251.BackColor = System.Drawing.Color.White;
            this.label251.Location = new System.Drawing.Point(238, 112);
            this.label251.Name = "label251";
            this.label251.Size = new System.Drawing.Size(2, 2);
            this.label251.TabIndex = 415;
            // 
            // label252
            // 
            this.label252.BackColor = System.Drawing.Color.White;
            this.label252.Location = new System.Drawing.Point(238, 103);
            this.label252.Name = "label252";
            this.label252.Size = new System.Drawing.Size(2, 2);
            this.label252.TabIndex = 414;
            // 
            // label256
            // 
            this.label256.BackColor = System.Drawing.Color.White;
            this.label256.Location = new System.Drawing.Point(202, 122);
            this.label256.Name = "label256";
            this.label256.Size = new System.Drawing.Size(2, 2);
            this.label256.TabIndex = 410;
            // 
            // label257
            // 
            this.label257.BackColor = System.Drawing.Color.White;
            this.label257.Location = new System.Drawing.Point(238, 122);
            this.label257.Name = "label257";
            this.label257.Size = new System.Drawing.Size(2, 2);
            this.label257.TabIndex = 409;
            // 
            // label258
            // 
            this.label258.BackColor = System.Drawing.Color.White;
            this.label258.Location = new System.Drawing.Point(229, 122);
            this.label258.Name = "label258";
            this.label258.Size = new System.Drawing.Size(2, 2);
            this.label258.TabIndex = 408;
            // 
            // label259
            // 
            this.label259.BackColor = System.Drawing.Color.White;
            this.label259.Location = new System.Drawing.Point(220, 122);
            this.label259.Name = "label259";
            this.label259.Size = new System.Drawing.Size(2, 2);
            this.label259.TabIndex = 407;
            // 
            // label260
            // 
            this.label260.BackColor = System.Drawing.Color.White;
            this.label260.Location = new System.Drawing.Point(211, 122);
            this.label260.Name = "label260";
            this.label260.Size = new System.Drawing.Size(2, 2);
            this.label260.TabIndex = 406;
            // 
            // label261
            // 
            this.label261.BackColor = System.Drawing.Color.White;
            this.label261.Location = new System.Drawing.Point(165, 122);
            this.label261.Name = "label261";
            this.label261.Size = new System.Drawing.Size(2, 2);
            this.label261.TabIndex = 405;
            // 
            // label262
            // 
            this.label262.BackColor = System.Drawing.Color.White;
            this.label262.Location = new System.Drawing.Point(156, 122);
            this.label262.Name = "label262";
            this.label262.Size = new System.Drawing.Size(2, 2);
            this.label262.TabIndex = 404;
            // 
            // label263
            // 
            this.label263.BackColor = System.Drawing.Color.White;
            this.label263.Location = new System.Drawing.Point(147, 122);
            this.label263.Name = "label263";
            this.label263.Size = new System.Drawing.Size(2, 2);
            this.label263.TabIndex = 403;
            // 
            // label264
            // 
            this.label264.BackColor = System.Drawing.Color.White;
            this.label264.Location = new System.Drawing.Point(138, 122);
            this.label264.Name = "label264";
            this.label264.Size = new System.Drawing.Size(2, 2);
            this.label264.TabIndex = 402;
            // 
            // label265
            // 
            this.label265.BackColor = System.Drawing.Color.White;
            this.label265.Location = new System.Drawing.Point(129, 122);
            this.label265.Name = "label265";
            this.label265.Size = new System.Drawing.Size(2, 2);
            this.label265.TabIndex = 401;
            // 
            // label272
            // 
            this.label272.BackColor = System.Drawing.Color.White;
            this.label272.Location = new System.Drawing.Point(192, 85);
            this.label272.Name = "label272";
            this.label272.Size = new System.Drawing.Size(2, 2);
            this.label272.TabIndex = 432;
            // 
            // label273
            // 
            this.label273.BackColor = System.Drawing.Color.White;
            this.label273.Location = new System.Drawing.Point(183, 85);
            this.label273.Name = "label273";
            this.label273.Size = new System.Drawing.Size(2, 2);
            this.label273.TabIndex = 431;
            // 
            // label274
            // 
            this.label274.BackColor = System.Drawing.Color.White;
            this.label274.Location = new System.Drawing.Point(174, 85);
            this.label274.Name = "label274";
            this.label274.Size = new System.Drawing.Size(2, 2);
            this.label274.TabIndex = 430;
            // 
            // label280
            // 
            this.label280.BackColor = System.Drawing.Color.White;
            this.label280.Location = new System.Drawing.Point(165, 85);
            this.label280.Name = "label280";
            this.label280.Size = new System.Drawing.Size(2, 2);
            this.label280.TabIndex = 424;
            // 
            // label281
            // 
            this.label281.BackColor = System.Drawing.Color.White;
            this.label281.Location = new System.Drawing.Point(156, 85);
            this.label281.Name = "label281";
            this.label281.Size = new System.Drawing.Size(2, 2);
            this.label281.TabIndex = 423;
            // 
            // label282
            // 
            this.label282.BackColor = System.Drawing.Color.White;
            this.label282.Location = new System.Drawing.Point(147, 85);
            this.label282.Name = "label282";
            this.label282.Size = new System.Drawing.Size(2, 2);
            this.label282.TabIndex = 422;
            // 
            // label283
            // 
            this.label283.BackColor = System.Drawing.Color.White;
            this.label283.Location = new System.Drawing.Point(138, 85);
            this.label283.Name = "label283";
            this.label283.Size = new System.Drawing.Size(2, 2);
            this.label283.TabIndex = 421;
            // 
            // label284
            // 
            this.label284.BackColor = System.Drawing.Color.White;
            this.label284.Location = new System.Drawing.Point(129, 85);
            this.label284.Name = "label284";
            this.label284.Size = new System.Drawing.Size(2, 2);
            this.label284.TabIndex = 420;
            // 
            // label266
            // 
            this.label266.BackColor = System.Drawing.Color.White;
            this.label266.Location = new System.Drawing.Point(94, 66);
            this.label266.Name = "label266";
            this.label266.Size = new System.Drawing.Size(2, 2);
            this.label266.TabIndex = 449;
            // 
            // label267
            // 
            this.label267.BackColor = System.Drawing.Color.White;
            this.label267.Location = new System.Drawing.Point(94, 76);
            this.label267.Name = "label267";
            this.label267.Size = new System.Drawing.Size(2, 2);
            this.label267.TabIndex = 448;
            // 
            // label268
            // 
            this.label268.BackColor = System.Drawing.Color.White;
            this.label268.Location = new System.Drawing.Point(94, 47);
            this.label268.Name = "label268";
            this.label268.Size = new System.Drawing.Size(2, 2);
            this.label268.TabIndex = 447;
            // 
            // label269
            // 
            this.label269.BackColor = System.Drawing.Color.White;
            this.label269.Location = new System.Drawing.Point(94, 57);
            this.label269.Name = "label269";
            this.label269.Size = new System.Drawing.Size(2, 2);
            this.label269.TabIndex = 446;
            // 
            // label270
            // 
            this.label270.BackColor = System.Drawing.Color.White;
            this.label270.Location = new System.Drawing.Point(138, 38);
            this.label270.Name = "label270";
            this.label270.Size = new System.Drawing.Size(2, 2);
            this.label270.TabIndex = 445;
            // 
            // label271
            // 
            this.label271.BackColor = System.Drawing.Color.White;
            this.label271.Location = new System.Drawing.Point(129, 38);
            this.label271.Name = "label271";
            this.label271.Size = new System.Drawing.Size(2, 2);
            this.label271.TabIndex = 444;
            // 
            // label275
            // 
            this.label275.BackColor = System.Drawing.Color.White;
            this.label275.Location = new System.Drawing.Point(120, 38);
            this.label275.Name = "label275";
            this.label275.Size = new System.Drawing.Size(2, 2);
            this.label275.TabIndex = 443;
            // 
            // label276
            // 
            this.label276.BackColor = System.Drawing.Color.White;
            this.label276.Location = new System.Drawing.Point(111, 38);
            this.label276.Name = "label276";
            this.label276.Size = new System.Drawing.Size(2, 2);
            this.label276.TabIndex = 442;
            // 
            // label277
            // 
            this.label277.BackColor = System.Drawing.Color.White;
            this.label277.Location = new System.Drawing.Point(102, 38);
            this.label277.Name = "label277";
            this.label277.Size = new System.Drawing.Size(2, 2);
            this.label277.TabIndex = 441;
            // 
            // label278
            // 
            this.label278.BackColor = System.Drawing.Color.White;
            this.label278.Location = new System.Drawing.Point(94, 38);
            this.label278.Name = "label278";
            this.label278.Size = new System.Drawing.Size(2, 2);
            this.label278.TabIndex = 440;
            // 
            // label279
            // 
            this.label279.BackColor = System.Drawing.Color.White;
            this.label279.Location = new System.Drawing.Point(165, 38);
            this.label279.Name = "label279";
            this.label279.Size = new System.Drawing.Size(2, 2);
            this.label279.TabIndex = 439;
            // 
            // label285
            // 
            this.label285.BackColor = System.Drawing.Color.White;
            this.label285.Location = new System.Drawing.Point(156, 38);
            this.label285.Name = "label285";
            this.label285.Size = new System.Drawing.Size(2, 2);
            this.label285.TabIndex = 438;
            // 
            // label286
            // 
            this.label286.BackColor = System.Drawing.Color.White;
            this.label286.Location = new System.Drawing.Point(147, 38);
            this.label286.Name = "label286";
            this.label286.Size = new System.Drawing.Size(2, 2);
            this.label286.TabIndex = 437;
            // 
            // label287
            // 
            this.label287.BackColor = System.Drawing.Color.White;
            this.label287.Location = new System.Drawing.Point(165, 66);
            this.label287.Name = "label287";
            this.label287.Size = new System.Drawing.Size(2, 2);
            this.label287.TabIndex = 436;
            // 
            // label288
            // 
            this.label288.BackColor = System.Drawing.Color.White;
            this.label288.Location = new System.Drawing.Point(165, 76);
            this.label288.Name = "label288";
            this.label288.Size = new System.Drawing.Size(2, 2);
            this.label288.TabIndex = 435;
            // 
            // label289
            // 
            this.label289.BackColor = System.Drawing.Color.White;
            this.label289.Location = new System.Drawing.Point(165, 47);
            this.label289.Name = "label289";
            this.label289.Size = new System.Drawing.Size(2, 2);
            this.label289.TabIndex = 434;
            // 
            // label290
            // 
            this.label290.BackColor = System.Drawing.Color.White;
            this.label290.Location = new System.Drawing.Point(165, 57);
            this.label290.Name = "label290";
            this.label290.Size = new System.Drawing.Size(2, 2);
            this.label290.TabIndex = 433;
            // 
            // label293
            // 
            this.label293.BackColor = System.Drawing.Color.White;
            this.label293.Location = new System.Drawing.Point(49, 85);
            this.label293.Name = "label293";
            this.label293.Size = new System.Drawing.Size(2, 2);
            this.label293.TabIndex = 459;
            // 
            // label294
            // 
            this.label294.BackColor = System.Drawing.Color.White;
            this.label294.Location = new System.Drawing.Point(40, 85);
            this.label294.Name = "label294";
            this.label294.Size = new System.Drawing.Size(2, 2);
            this.label294.TabIndex = 458;
            // 
            // label295
            // 
            this.label295.BackColor = System.Drawing.Color.White;
            this.label295.Location = new System.Drawing.Point(111, 85);
            this.label295.Name = "label295";
            this.label295.Size = new System.Drawing.Size(2, 2);
            this.label295.TabIndex = 457;
            // 
            // label296
            // 
            this.label296.BackColor = System.Drawing.Color.White;
            this.label296.Location = new System.Drawing.Point(103, 85);
            this.label296.Name = "label296";
            this.label296.Size = new System.Drawing.Size(2, 2);
            this.label296.TabIndex = 456;
            // 
            // label297
            // 
            this.label297.BackColor = System.Drawing.Color.White;
            this.label297.Location = new System.Drawing.Point(94, 85);
            this.label297.Name = "label297";
            this.label297.Size = new System.Drawing.Size(2, 2);
            this.label297.TabIndex = 455;
            // 
            // label298
            // 
            this.label298.BackColor = System.Drawing.Color.White;
            this.label298.Location = new System.Drawing.Point(85, 85);
            this.label298.Name = "label298";
            this.label298.Size = new System.Drawing.Size(2, 2);
            this.label298.TabIndex = 454;
            // 
            // label299
            // 
            this.label299.BackColor = System.Drawing.Color.White;
            this.label299.Location = new System.Drawing.Point(76, 85);
            this.label299.Name = "label299";
            this.label299.Size = new System.Drawing.Size(2, 2);
            this.label299.TabIndex = 453;
            // 
            // label300
            // 
            this.label300.BackColor = System.Drawing.Color.White;
            this.label300.Location = new System.Drawing.Point(67, 85);
            this.label300.Name = "label300";
            this.label300.Size = new System.Drawing.Size(2, 2);
            this.label300.TabIndex = 452;
            // 
            // label301
            // 
            this.label301.BackColor = System.Drawing.Color.White;
            this.label301.Location = new System.Drawing.Point(120, 85);
            this.label301.Name = "label301";
            this.label301.Size = new System.Drawing.Size(2, 2);
            this.label301.TabIndex = 451;
            // 
            // label302
            // 
            this.label302.BackColor = System.Drawing.Color.White;
            this.label302.Location = new System.Drawing.Point(58, 85);
            this.label302.Name = "label302";
            this.label302.Size = new System.Drawing.Size(2, 2);
            this.label302.TabIndex = 450;
            // 
            // label291
            // 
            this.label291.BackColor = System.Drawing.Color.White;
            this.label291.Location = new System.Drawing.Point(32, 94);
            this.label291.Name = "label291";
            this.label291.Size = new System.Drawing.Size(2, 2);
            this.label291.TabIndex = 469;
            // 
            // label292
            // 
            this.label292.BackColor = System.Drawing.Color.White;
            this.label292.Location = new System.Drawing.Point(32, 113);
            this.label292.Name = "label292";
            this.label292.Size = new System.Drawing.Size(2, 2);
            this.label292.TabIndex = 468;
            // 
            // label303
            // 
            this.label303.BackColor = System.Drawing.Color.White;
            this.label303.Location = new System.Drawing.Point(32, 104);
            this.label303.Name = "label303";
            this.label303.Size = new System.Drawing.Size(2, 2);
            this.label303.TabIndex = 467;
            // 
            // label304
            // 
            this.label304.BackColor = System.Drawing.Color.White;
            this.label304.Location = new System.Drawing.Point(32, 122);
            this.label304.Name = "label304";
            this.label304.Size = new System.Drawing.Size(2, 2);
            this.label304.TabIndex = 466;
            // 
            // label305
            // 
            this.label305.BackColor = System.Drawing.Color.White;
            this.label305.Location = new System.Drawing.Point(32, 76);
            this.label305.Name = "label305";
            this.label305.Size = new System.Drawing.Size(2, 2);
            this.label305.TabIndex = 465;
            // 
            // label306
            // 
            this.label306.BackColor = System.Drawing.Color.White;
            this.label306.Location = new System.Drawing.Point(32, 67);
            this.label306.Name = "label306";
            this.label306.Size = new System.Drawing.Size(2, 2);
            this.label306.TabIndex = 464;
            // 
            // label307
            // 
            this.label307.BackColor = System.Drawing.Color.Black;
            this.label307.Image = ((System.Drawing.Image)(resources.GetObject("label307.Image")));
            this.label307.Location = new System.Drawing.Point(28, 54);
            this.label307.Name = "label307";
            this.label307.Size = new System.Drawing.Size(10, 10);
            this.label307.TabIndex = 463;
            // 
            // label308
            // 
            this.label308.BackColor = System.Drawing.Color.White;
            this.label308.Location = new System.Drawing.Point(32, 85);
            this.label308.Name = "label308";
            this.label308.Size = new System.Drawing.Size(2, 2);
            this.label308.TabIndex = 462;
            // 
            // label309
            // 
            this.label309.BackColor = System.Drawing.Color.White;
            this.label309.Location = new System.Drawing.Point(32, 48);
            this.label309.Name = "label309";
            this.label309.Size = new System.Drawing.Size(2, 2);
            this.label309.TabIndex = 461;
            // 
            // label310
            // 
            this.label310.BackColor = System.Drawing.Color.White;
            this.label310.Location = new System.Drawing.Point(32, 38);
            this.label310.Name = "label310";
            this.label310.Size = new System.Drawing.Size(2, 2);
            this.label310.TabIndex = 460;
            // 
            // label311
            // 
            this.label311.BackColor = System.Drawing.Color.White;
            this.label311.Location = new System.Drawing.Point(85, 38);
            this.label311.Name = "label311";
            this.label311.Size = new System.Drawing.Size(2, 2);
            this.label311.TabIndex = 475;
            // 
            // label312
            // 
            this.label312.BackColor = System.Drawing.Color.White;
            this.label312.Location = new System.Drawing.Point(77, 38);
            this.label312.Name = "label312";
            this.label312.Size = new System.Drawing.Size(2, 2);
            this.label312.TabIndex = 474;
            // 
            // label313
            // 
            this.label313.BackColor = System.Drawing.Color.White;
            this.label313.Location = new System.Drawing.Point(68, 38);
            this.label313.Name = "label313";
            this.label313.Size = new System.Drawing.Size(2, 2);
            this.label313.TabIndex = 473;
            // 
            // label314
            // 
            this.label314.BackColor = System.Drawing.Color.White;
            this.label314.Location = new System.Drawing.Point(59, 38);
            this.label314.Name = "label314";
            this.label314.Size = new System.Drawing.Size(2, 2);
            this.label314.TabIndex = 472;
            // 
            // label315
            // 
            this.label315.BackColor = System.Drawing.Color.White;
            this.label315.Location = new System.Drawing.Point(50, 38);
            this.label315.Name = "label315";
            this.label315.Size = new System.Drawing.Size(2, 2);
            this.label315.TabIndex = 471;
            // 
            // label316
            // 
            this.label316.BackColor = System.Drawing.Color.White;
            this.label316.Location = new System.Drawing.Point(41, 38);
            this.label316.Name = "label316";
            this.label316.Size = new System.Drawing.Size(2, 2);
            this.label316.TabIndex = 470;
            // 
            // label317
            // 
            this.label317.BackColor = System.Drawing.Color.White;
            this.label317.Location = new System.Drawing.Point(85, 122);
            this.label317.Name = "label317";
            this.label317.Size = new System.Drawing.Size(2, 2);
            this.label317.TabIndex = 482;
            // 
            // label318
            // 
            this.label318.BackColor = System.Drawing.Color.White;
            this.label318.Location = new System.Drawing.Point(76, 122);
            this.label318.Name = "label318";
            this.label318.Size = new System.Drawing.Size(2, 2);
            this.label318.TabIndex = 481;
            // 
            // label319
            // 
            this.label319.BackColor = System.Drawing.Color.White;
            this.label319.Location = new System.Drawing.Point(67, 122);
            this.label319.Name = "label319";
            this.label319.Size = new System.Drawing.Size(2, 2);
            this.label319.TabIndex = 480;
            // 
            // label320
            // 
            this.label320.BackColor = System.Drawing.Color.White;
            this.label320.Location = new System.Drawing.Point(58, 122);
            this.label320.Name = "label320";
            this.label320.Size = new System.Drawing.Size(2, 2);
            this.label320.TabIndex = 479;
            // 
            // label321
            // 
            this.label321.BackColor = System.Drawing.Color.White;
            this.label321.Location = new System.Drawing.Point(49, 122);
            this.label321.Name = "label321";
            this.label321.Size = new System.Drawing.Size(2, 2);
            this.label321.TabIndex = 478;
            // 
            // label322
            // 
            this.label322.BackColor = System.Drawing.Color.White;
            this.label322.Location = new System.Drawing.Point(40, 122);
            this.label322.Name = "label322";
            this.label322.Size = new System.Drawing.Size(2, 2);
            this.label322.TabIndex = 477;
            // 
            // label323
            // 
            this.label323.BackColor = System.Drawing.Color.White;
            this.label323.Location = new System.Drawing.Point(94, 122);
            this.label323.Name = "label323";
            this.label323.Size = new System.Drawing.Size(2, 2);
            this.label323.TabIndex = 476;
            // 
            // label324
            // 
            this.label324.BackColor = System.Drawing.Color.White;
            this.label324.Location = new System.Drawing.Point(94, 103);
            this.label324.Name = "label324";
            this.label324.Size = new System.Drawing.Size(2, 2);
            this.label324.TabIndex = 486;
            // 
            // label325
            // 
            this.label325.BackColor = System.Drawing.Color.White;
            this.label325.Location = new System.Drawing.Point(94, 113);
            this.label325.Name = "label325";
            this.label325.Size = new System.Drawing.Size(2, 2);
            this.label325.TabIndex = 485;
            // 
            // label327
            // 
            this.label327.BackColor = System.Drawing.Color.White;
            this.label327.Location = new System.Drawing.Point(94, 94);
            this.label327.Name = "label327";
            this.label327.Size = new System.Drawing.Size(2, 2);
            this.label327.TabIndex = 483;
            // 
            // label326
            // 
            this.label326.BackColor = System.Drawing.Color.White;
            this.label326.Location = new System.Drawing.Point(94, 149);
            this.label326.Name = "label326";
            this.label326.Size = new System.Drawing.Size(2, 2);
            this.label326.TabIndex = 501;
            // 
            // label328
            // 
            this.label328.BackColor = System.Drawing.Color.White;
            this.label328.Location = new System.Drawing.Point(94, 167);
            this.label328.Name = "label328";
            this.label328.Size = new System.Drawing.Size(2, 2);
            this.label328.TabIndex = 500;
            // 
            // label329
            // 
            this.label329.BackColor = System.Drawing.Color.White;
            this.label329.Location = new System.Drawing.Point(94, 158);
            this.label329.Name = "label329";
            this.label329.Size = new System.Drawing.Size(2, 2);
            this.label329.TabIndex = 499;
            // 
            // label330
            // 
            this.label330.BackColor = System.Drawing.Color.White;
            this.label330.Location = new System.Drawing.Point(94, 176);
            this.label330.Name = "label330";
            this.label330.Size = new System.Drawing.Size(2, 2);
            this.label330.TabIndex = 498;
            // 
            // label331
            // 
            this.label331.BackColor = System.Drawing.Color.White;
            this.label331.Location = new System.Drawing.Point(94, 131);
            this.label331.Name = "label331";
            this.label331.Size = new System.Drawing.Size(2, 2);
            this.label331.TabIndex = 497;
            // 
            // label332
            // 
            this.label332.BackColor = System.Drawing.Color.White;
            this.label332.Location = new System.Drawing.Point(94, 140);
            this.label332.Name = "label332";
            this.label332.Size = new System.Drawing.Size(2, 2);
            this.label332.TabIndex = 496;
            // 
            // label333
            // 
            this.label333.BackColor = System.Drawing.Color.White;
            this.label333.Location = new System.Drawing.Point(94, 230);
            this.label333.Name = "label333";
            this.label333.Size = new System.Drawing.Size(2, 2);
            this.label333.TabIndex = 495;
            // 
            // label334
            // 
            this.label334.BackColor = System.Drawing.Color.White;
            this.label334.Location = new System.Drawing.Point(94, 248);
            this.label334.Name = "label334";
            this.label334.Size = new System.Drawing.Size(2, 2);
            this.label334.TabIndex = 494;
            // 
            // label335
            // 
            this.label335.BackColor = System.Drawing.Color.White;
            this.label335.Location = new System.Drawing.Point(94, 239);
            this.label335.Name = "label335";
            this.label335.Size = new System.Drawing.Size(2, 2);
            this.label335.TabIndex = 493;
            // 
            // label336
            // 
            this.label336.BackColor = System.Drawing.Color.White;
            this.label336.Location = new System.Drawing.Point(94, 257);
            this.label336.Name = "label336";
            this.label336.Size = new System.Drawing.Size(2, 2);
            this.label336.TabIndex = 492;
            // 
            // label337
            // 
            this.label337.BackColor = System.Drawing.Color.White;
            this.label337.Location = new System.Drawing.Point(94, 212);
            this.label337.Name = "label337";
            this.label337.Size = new System.Drawing.Size(2, 2);
            this.label337.TabIndex = 491;
            // 
            // label338
            // 
            this.label338.BackColor = System.Drawing.Color.White;
            this.label338.Location = new System.Drawing.Point(94, 203);
            this.label338.Name = "label338";
            this.label338.Size = new System.Drawing.Size(2, 2);
            this.label338.TabIndex = 490;
            // 
            // label339
            // 
            this.label339.BackColor = System.Drawing.Color.White;
            this.label339.Location = new System.Drawing.Point(94, 194);
            this.label339.Name = "label339";
            this.label339.Size = new System.Drawing.Size(2, 2);
            this.label339.TabIndex = 489;
            // 
            // label340
            // 
            this.label340.BackColor = System.Drawing.Color.White;
            this.label340.Location = new System.Drawing.Point(94, 221);
            this.label340.Name = "label340";
            this.label340.Size = new System.Drawing.Size(2, 2);
            this.label340.TabIndex = 488;
            // 
            // label341
            // 
            this.label341.BackColor = System.Drawing.Color.White;
            this.label341.Location = new System.Drawing.Point(94, 185);
            this.label341.Name = "label341";
            this.label341.Size = new System.Drawing.Size(2, 2);
            this.label341.TabIndex = 487;
            // 
            // timer8
            // 
            this.timer8.Interval = 700;
            this.timer8.Tick += new System.EventHandler(this.timer8_Tick);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label254);
            this.panel1.Controls.Add(this.label255);
            this.panel1.Controls.Add(this.label253);
            this.panel1.Controls.Add(this.label142);
            this.panel1.Controls.Add(this.pictureBox5);
            this.panel1.Controls.Add(this.pictureBox4);
            this.panel1.Controls.Add(this.pictureBox3);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(370, 430);
            this.panel1.TabIndex = 502;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::Pacman_Zagorschi_Franco.Properties.Resources.bg_name;
            this.pictureBox5.Location = new System.Drawing.Point(12, 226);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(348, 171);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 7;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.Click += new System.EventHandler(this.pictureBox5_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::Pacman_Zagorschi_Franco.Properties.Resources.exit;
            this.pictureBox4.Location = new System.Drawing.Point(163, 158);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(50, 50);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 2;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Click += new System.EventHandler(this.pictureBox4_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::Pacman_Zagorschi_Franco.Properties.Resources.pacman_bg;
            this.pictureBox3.Location = new System.Drawing.Point(12, 18);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(348, 101);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 1;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Visible = false;
            // 
            // button1
            // 
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black;
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Image = global::Pacman_Zagorschi_Franco.Properties.Resources.playgame;
            this.button1.Location = new System.Drawing.Point(123, 124);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(136, 36);
            this.button1.TabIndex = 0;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Visible = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            this.button1.MouseEnter += new System.EventHandler(this.button1_MouseEnter);
            this.button1.MouseLeave += new System.EventHandler(this.button1_MouseLeave);
            // 
            // pacman
            // 
            this.pacman.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pacman.Cursor = System.Windows.Forms.Cursors.Default;
            this.pacman.Image = global::Pacman_Zagorschi_Franco.Properties.Resources.pacdx;
            this.pacman.Location = new System.Drawing.Point(24, 364);
            this.pacman.Name = "pacman";
            this.pacman.Size = new System.Drawing.Size(22, 22);
            this.pacman.TabIndex = 503;
            this.pacman.TabStop = false;
            // 
            // powermod
            // 
            this.powermod.Interval = 10000;
            this.powermod.Tick += new System.EventHandler(this.powermod_Tick);
            // 
            // timer7
            // 
            this.timer7.Interval = 2500;
            this.timer7.Tick += new System.EventHandler(this.timer7_Tick);
            // 
            // timer9
            // 
            this.timer9.Enabled = true;
            this.timer9.Interval = 200;
            this.timer9.Tick += new System.EventHandler(this.timer9_Tick);
            // 
            // ghostmangiato
            // 
            this.ghostmangiato.Interval = 500;
            this.ghostmangiato.Tick += new System.EventHandler(this.ghostmangiato_Tick);
            // 
            // label124
            // 
            this.label124.BackColor = System.Drawing.Color.Black;
            this.label124.Font = new System.Drawing.Font("Segoe UI Black", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label124.ForeColor = System.Drawing.Color.White;
            this.label124.Image = global::Pacman_Zagorschi_Franco.Properties.Resources.gameover;
            this.label124.Location = new System.Drawing.Point(123, 222);
            this.label124.Name = "label124";
            this.label124.Size = new System.Drawing.Size(125, 19);
            this.label124.TabIndex = 504;
            this.label124.Text = "          ";
            this.label124.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label124.Visible = false;
            // 
            // label141
            // 
            this.label141.BackColor = System.Drawing.Color.Black;
            this.label141.Font = new System.Drawing.Font("Segoe UI Black", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label141.ForeColor = System.Drawing.Color.White;
            this.label141.Image = global::Pacman_Zagorschi_Franco.Properties.Resources.gamewin1;
            this.label141.Location = new System.Drawing.Point(125, 222);
            this.label141.Name = "label141";
            this.label141.Size = new System.Drawing.Size(125, 19);
            this.label141.TabIndex = 505;
            this.label141.Text = "          ";
            this.label141.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label141.Visible = false;
            // 
            // powermod1
            // 
            this.powermod1.Interval = 7000;
            this.powermod1.Tick += new System.EventHandler(this.powermod1_Tick);
            // 
            // attendo
            // 
            this.attendo.Interval = 400;
            this.attendo.Tick += new System.EventHandler(this.attendo_Tick);
            // 
            // label254
            // 
            this.label254.AutoSize = true;
            this.label254.Font = new System.Drawing.Font("News706 BT", 12.25F, System.Drawing.FontStyle.Bold);
            this.label254.ForeColor = System.Drawing.Color.White;
            this.label254.Location = new System.Drawing.Point(128, 354);
            this.label254.Name = "label254";
            this.label254.Size = new System.Drawing.Size(122, 20);
            this.label254.TabIndex = 11;
            this.label254.Text = "(15050623024)";
            this.label254.Click += new System.EventHandler(this.label254_Click_1);
            // 
            // label255
            // 
            this.label255.AutoSize = true;
            this.label255.Font = new System.Drawing.Font("News706 BT", 13.25F, System.Drawing.FontStyle.Bold);
            this.label255.ForeColor = System.Drawing.Color.White;
            this.label255.Location = new System.Drawing.Point(97, 331);
            this.label255.Name = "label255";
            this.label255.Size = new System.Drawing.Size(197, 21);
            this.label255.TabIndex = 10;
            this.label255.Text = "Fahmi Rizky Maulidy";
            // 
            // label253
            // 
            this.label253.AutoSize = true;
            this.label253.Font = new System.Drawing.Font("News706 BT", 12.25F, System.Drawing.FontStyle.Bold);
            this.label253.ForeColor = System.Drawing.Color.White;
            this.label253.Location = new System.Drawing.Point(126, 277);
            this.label253.Name = "label253";
            this.label253.Size = new System.Drawing.Size(122, 20);
            this.label253.TabIndex = 9;
            this.label253.Text = "(15050623021)";
            // 
            // label142
            // 
            this.label142.AutoSize = true;
            this.label142.BackColor = System.Drawing.Color.Transparent;
            this.label142.Font = new System.Drawing.Font("News706 BT", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label142.ForeColor = System.Drawing.SystemColors.Window;
            this.label142.Location = new System.Drawing.Point(53, 255);
            this.label142.Name = "label142";
            this.label142.Size = new System.Drawing.Size(266, 20);
            this.label142.TabIndex = 8;
            this.label142.Text = "Muhammad Akbar Priambodo ";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.BackgroundImage = global::Pacman_Zagorschi_Franco.Properties.Resources.percorso;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(370, 430);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.ghost3);
            this.Controls.Add(this.ghost4);
            this.Controls.Add(this.ghost2);
            this.Controls.Add(this.ghost1);
            this.Controls.Add(this.label141);
            this.Controls.Add(this.label124);
            this.Controls.Add(this.pacman);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label326);
            this.Controls.Add(this.label328);
            this.Controls.Add(this.label329);
            this.Controls.Add(this.label330);
            this.Controls.Add(this.label331);
            this.Controls.Add(this.label332);
            this.Controls.Add(this.label333);
            this.Controls.Add(this.label334);
            this.Controls.Add(this.label335);
            this.Controls.Add(this.label336);
            this.Controls.Add(this.label337);
            this.Controls.Add(this.label338);
            this.Controls.Add(this.label339);
            this.Controls.Add(this.label340);
            this.Controls.Add(this.label341);
            this.Controls.Add(this.label324);
            this.Controls.Add(this.label325);
            this.Controls.Add(this.label327);
            this.Controls.Add(this.label317);
            this.Controls.Add(this.label318);
            this.Controls.Add(this.label319);
            this.Controls.Add(this.label320);
            this.Controls.Add(this.label321);
            this.Controls.Add(this.label322);
            this.Controls.Add(this.label323);
            this.Controls.Add(this.label311);
            this.Controls.Add(this.label312);
            this.Controls.Add(this.label313);
            this.Controls.Add(this.label314);
            this.Controls.Add(this.label315);
            this.Controls.Add(this.label316);
            this.Controls.Add(this.label291);
            this.Controls.Add(this.label292);
            this.Controls.Add(this.label303);
            this.Controls.Add(this.label304);
            this.Controls.Add(this.label305);
            this.Controls.Add(this.label306);
            this.Controls.Add(this.label307);
            this.Controls.Add(this.label308);
            this.Controls.Add(this.label309);
            this.Controls.Add(this.label310);
            this.Controls.Add(this.label293);
            this.Controls.Add(this.label294);
            this.Controls.Add(this.label295);
            this.Controls.Add(this.label296);
            this.Controls.Add(this.label297);
            this.Controls.Add(this.label298);
            this.Controls.Add(this.label299);
            this.Controls.Add(this.label300);
            this.Controls.Add(this.label301);
            this.Controls.Add(this.label302);
            this.Controls.Add(this.label266);
            this.Controls.Add(this.label267);
            this.Controls.Add(this.label268);
            this.Controls.Add(this.label269);
            this.Controls.Add(this.label270);
            this.Controls.Add(this.label271);
            this.Controls.Add(this.label275);
            this.Controls.Add(this.label276);
            this.Controls.Add(this.label277);
            this.Controls.Add(this.label278);
            this.Controls.Add(this.label279);
            this.Controls.Add(this.label285);
            this.Controls.Add(this.label286);
            this.Controls.Add(this.label287);
            this.Controls.Add(this.label288);
            this.Controls.Add(this.label289);
            this.Controls.Add(this.label290);
            this.Controls.Add(this.label272);
            this.Controls.Add(this.label273);
            this.Controls.Add(this.label274);
            this.Controls.Add(this.label280);
            this.Controls.Add(this.label281);
            this.Controls.Add(this.label282);
            this.Controls.Add(this.label283);
            this.Controls.Add(this.label284);
            this.Controls.Add(this.label247);
            this.Controls.Add(this.label248);
            this.Controls.Add(this.label249);
            this.Controls.Add(this.label250);
            this.Controls.Add(this.label251);
            this.Controls.Add(this.label252);
            this.Controls.Add(this.label256);
            this.Controls.Add(this.label257);
            this.Controls.Add(this.label258);
            this.Controls.Add(this.label259);
            this.Controls.Add(this.label260);
            this.Controls.Add(this.label261);
            this.Controls.Add(this.label262);
            this.Controls.Add(this.label263);
            this.Controls.Add(this.label264);
            this.Controls.Add(this.label265);
            this.Controls.Add(this.label243);
            this.Controls.Add(this.label244);
            this.Controls.Add(this.label245);
            this.Controls.Add(this.label246);
            this.Controls.Add(this.label235);
            this.Controls.Add(this.label236);
            this.Controls.Add(this.label237);
            this.Controls.Add(this.label238);
            this.Controls.Add(this.label239);
            this.Controls.Add(this.label240);
            this.Controls.Add(this.label241);
            this.Controls.Add(this.label242);
            this.Controls.Add(this.label229);
            this.Controls.Add(this.label230);
            this.Controls.Add(this.label231);
            this.Controls.Add(this.label232);
            this.Controls.Add(this.label233);
            this.Controls.Add(this.label234);
            this.Controls.Add(this.label223);
            this.Controls.Add(this.label224);
            this.Controls.Add(this.label225);
            this.Controls.Add(this.label226);
            this.Controls.Add(this.label227);
            this.Controls.Add(this.label228);
            this.Controls.Add(this.label197);
            this.Controls.Add(this.label215);
            this.Controls.Add(this.label216);
            this.Controls.Add(this.label217);
            this.Controls.Add(this.label218);
            this.Controls.Add(this.label219);
            this.Controls.Add(this.label220);
            this.Controls.Add(this.label221);
            this.Controls.Add(this.label222);
            this.Controls.Add(this.label198);
            this.Controls.Add(this.label200);
            this.Controls.Add(this.label201);
            this.Controls.Add(this.label202);
            this.Controls.Add(this.label203);
            this.Controls.Add(this.label204);
            this.Controls.Add(this.label205);
            this.Controls.Add(this.label206);
            this.Controls.Add(this.label207);
            this.Controls.Add(this.label208);
            this.Controls.Add(this.label209);
            this.Controls.Add(this.label210);
            this.Controls.Add(this.label211);
            this.Controls.Add(this.label212);
            this.Controls.Add(this.label213);
            this.Controls.Add(this.label214);
            this.Controls.Add(this.label192);
            this.Controls.Add(this.label193);
            this.Controls.Add(this.label194);
            this.Controls.Add(this.label195);
            this.Controls.Add(this.label196);
            this.Controls.Add(this.label199);
            this.Controls.Add(this.label183);
            this.Controls.Add(this.label184);
            this.Controls.Add(this.label185);
            this.Controls.Add(this.label186);
            this.Controls.Add(this.label187);
            this.Controls.Add(this.label188);
            this.Controls.Add(this.label189);
            this.Controls.Add(this.label190);
            this.Controls.Add(this.label191);
            this.Controls.Add(this.label174);
            this.Controls.Add(this.label175);
            this.Controls.Add(this.label176);
            this.Controls.Add(this.label177);
            this.Controls.Add(this.label178);
            this.Controls.Add(this.label179);
            this.Controls.Add(this.label180);
            this.Controls.Add(this.label181);
            this.Controls.Add(this.label182);
            this.Controls.Add(this.label170);
            this.Controls.Add(this.label171);
            this.Controls.Add(this.label172);
            this.Controls.Add(this.label173);
            this.Controls.Add(this.label169);
            this.Controls.Add(this.label166);
            this.Controls.Add(this.label167);
            this.Controls.Add(this.label168);
            this.Controls.Add(this.label163);
            this.Controls.Add(this.label164);
            this.Controls.Add(this.label165);
            this.Controls.Add(this.label119);
            this.Controls.Add(this.label120);
            this.Controls.Add(this.label121);
            this.Controls.Add(this.label122);
            this.Controls.Add(this.label123);
            this.Controls.Add(this.label125);
            this.Controls.Add(this.label126);
            this.Controls.Add(this.label127);
            this.Controls.Add(this.label128);
            this.Controls.Add(this.label129);
            this.Controls.Add(this.label130);
            this.Controls.Add(this.label131);
            this.Controls.Add(this.label132);
            this.Controls.Add(this.label133);
            this.Controls.Add(this.label134);
            this.Controls.Add(this.label135);
            this.Controls.Add(this.label136);
            this.Controls.Add(this.label137);
            this.Controls.Add(this.label138);
            this.Controls.Add(this.label139);
            this.Controls.Add(this.label140);
            this.Controls.Add(this.label143);
            this.Controls.Add(this.label144);
            this.Controls.Add(this.label145);
            this.Controls.Add(this.label146);
            this.Controls.Add(this.label147);
            this.Controls.Add(this.label148);
            this.Controls.Add(this.label149);
            this.Controls.Add(this.label150);
            this.Controls.Add(this.label151);
            this.Controls.Add(this.label152);
            this.Controls.Add(this.label153);
            this.Controls.Add(this.label154);
            this.Controls.Add(this.label155);
            this.Controls.Add(this.label156);
            this.Controls.Add(this.label157);
            this.Controls.Add(this.label158);
            this.Controls.Add(this.label159);
            this.Controls.Add(this.label160);
            this.Controls.Add(this.label161);
            this.Controls.Add(this.label162);
            this.Controls.Add(this.label105);
            this.Controls.Add(this.label106);
            this.Controls.Add(this.label107);
            this.Controls.Add(this.label108);
            this.Controls.Add(this.label109);
            this.Controls.Add(this.label110);
            this.Controls.Add(this.label111);
            this.Controls.Add(this.label112);
            this.Controls.Add(this.label113);
            this.Controls.Add(this.label114);
            this.Controls.Add(this.label115);
            this.Controls.Add(this.label116);
            this.Controls.Add(this.label117);
            this.Controls.Add(this.label118);
            this.Controls.Add(this.label103);
            this.Controls.Add(this.label104);
            this.Controls.Add(this.label97);
            this.Controls.Add(this.label99);
            this.Controls.Add(this.label100);
            this.Controls.Add(this.label101);
            this.Controls.Add(this.label102);
            this.Controls.Add(this.label93);
            this.Controls.Add(this.label95);
            this.Controls.Add(this.label96);
            this.Controls.Add(this.label98);
            this.Controls.Add(this.label90);
            this.Controls.Add(this.label91);
            this.Controls.Add(this.label92);
            this.Controls.Add(this.label94);
            this.Controls.Add(this.label86);
            this.Controls.Add(this.label87);
            this.Controls.Add(this.label88);
            this.Controls.Add(this.label89);
            this.Controls.Add(this.label75);
            this.Controls.Add(this.label84);
            this.Controls.Add(this.label85);
            this.Controls.Add(this.label80);
            this.Controls.Add(this.label81);
            this.Controls.Add(this.label82);
            this.Controls.Add(this.label83);
            this.Controls.Add(this.label76);
            this.Controls.Add(this.label77);
            this.Controls.Add(this.label78);
            this.Controls.Add(this.label79);
            this.Controls.Add(this.label71);
            this.Controls.Add(this.label72);
            this.Controls.Add(this.label73);
            this.Controls.Add(this.label74);
            this.Controls.Add(this.label70);
            this.Controls.Add(this.label67);
            this.Controls.Add(this.label68);
            this.Controls.Add(this.label69);
            this.Controls.Add(this.label66);
            this.Controls.Add(this.label64);
            this.Controls.Add(this.label65);
            this.Controls.Add(this.label61);
            this.Controls.Add(this.label62);
            this.Controls.Add(this.label63);
            this.Controls.Add(this.label58);
            this.Controls.Add(this.label59);
            this.Controls.Add(this.label60);
            this.Controls.Add(this.label42);
            this.Controls.Add(this.label48);
            this.Controls.Add(this.label51);
            this.Controls.Add(this.label52);
            this.Controls.Add(this.label53);
            this.Controls.Add(this.label54);
            this.Controls.Add(this.label55);
            this.Controls.Add(this.label56);
            this.Controls.Add(this.label57);
            this.Controls.Add(this.label33);
            this.Controls.Add(this.label34);
            this.Controls.Add(this.label35);
            this.Controls.Add(this.label36);
            this.Controls.Add(this.label37);
            this.Controls.Add(this.label38);
            this.Controls.Add(this.label39);
            this.Controls.Add(this.label40);
            this.Controls.Add(this.label41);
            this.Controls.Add(this.label50);
            this.Controls.Add(this.label49);
            this.Controls.Add(this.label45);
            this.Controls.Add(this.label46);
            this.Controls.Add(this.label47);
            this.Controls.Add(this.label44);
            this.Controls.Add(this.label43);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.score);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Cursor = System.Windows.Forms.Cursors.Default;
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.Black;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(386, 469);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(386, 469);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Pac-Man";
            this.TransparencyKey = System.Drawing.Color.Fuchsia;
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pacman)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label ghost1;
        private System.Windows.Forms.Label ghost2;
        private System.Windows.Forms.Label ghost4;
        private System.Windows.Forms.Label ghost3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Timer timer3;
        private System.Windows.Forms.Timer timer4;
        private System.Windows.Forms.Timer timer5;
        private System.Windows.Forms.Timer timer6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label score;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.Label label96;
        private System.Windows.Forms.Label label98;
        private System.Windows.Forms.Label label97;
        private System.Windows.Forms.Label label99;
        private System.Windows.Forms.Label label100;
        private System.Windows.Forms.Label label101;
        private System.Windows.Forms.Label label102;
        private System.Windows.Forms.Label label103;
        private System.Windows.Forms.Label label104;
        private System.Windows.Forms.Label label105;
        private System.Windows.Forms.Label label106;
        private System.Windows.Forms.Label label107;
        private System.Windows.Forms.Label label108;
        private System.Windows.Forms.Label label109;
        private System.Windows.Forms.Label label110;
        private System.Windows.Forms.Label label111;
        private System.Windows.Forms.Label label112;
        private System.Windows.Forms.Label label113;
        private System.Windows.Forms.Label label114;
        private System.Windows.Forms.Label label115;
        private System.Windows.Forms.Label label116;
        private System.Windows.Forms.Label label117;
        private System.Windows.Forms.Label label118;
        private System.Windows.Forms.Label label119;
        private System.Windows.Forms.Label label120;
        private System.Windows.Forms.Label label121;
        private System.Windows.Forms.Label label122;
        private System.Windows.Forms.Label label123;
        private System.Windows.Forms.Label label125;
        private System.Windows.Forms.Label label126;
        private System.Windows.Forms.Label label127;
        private System.Windows.Forms.Label label128;
        private System.Windows.Forms.Label label129;
        private System.Windows.Forms.Label label130;
        private System.Windows.Forms.Label label131;
        private System.Windows.Forms.Label label132;
        private System.Windows.Forms.Label label133;
        private System.Windows.Forms.Label label134;
        private System.Windows.Forms.Label label135;
        private System.Windows.Forms.Label label136;
        private System.Windows.Forms.Label label137;
        private System.Windows.Forms.Label label138;
        private System.Windows.Forms.Label label139;
        private System.Windows.Forms.Label label140;
        private System.Windows.Forms.Label label143;
        private System.Windows.Forms.Label label144;
        private System.Windows.Forms.Label label145;
        private System.Windows.Forms.Label label146;
        private System.Windows.Forms.Label label147;
        private System.Windows.Forms.Label label148;
        private System.Windows.Forms.Label label149;
        private System.Windows.Forms.Label label150;
        private System.Windows.Forms.Label label151;
        private System.Windows.Forms.Label label152;
        private System.Windows.Forms.Label label153;
        private System.Windows.Forms.Label label154;
        private System.Windows.Forms.Label label155;
        private System.Windows.Forms.Label label156;
        private System.Windows.Forms.Label label157;
        private System.Windows.Forms.Label label158;
        private System.Windows.Forms.Label label159;
        private System.Windows.Forms.Label label160;
        private System.Windows.Forms.Label label161;
        private System.Windows.Forms.Label label162;
        private System.Windows.Forms.Label label163;
        private System.Windows.Forms.Label label164;
        private System.Windows.Forms.Label label165;
        private System.Windows.Forms.Label label166;
        private System.Windows.Forms.Label label167;
        private System.Windows.Forms.Label label168;
        private System.Windows.Forms.Label label169;
        private System.Windows.Forms.Label label170;
        private System.Windows.Forms.Label label171;
        private System.Windows.Forms.Label label172;
        private System.Windows.Forms.Label label173;
        private System.Windows.Forms.Label label174;
        private System.Windows.Forms.Label label175;
        private System.Windows.Forms.Label label176;
        private System.Windows.Forms.Label label177;
        private System.Windows.Forms.Label label178;
        private System.Windows.Forms.Label label179;
        private System.Windows.Forms.Label label180;
        private System.Windows.Forms.Label label181;
        private System.Windows.Forms.Label label182;
        private System.Windows.Forms.Label label183;
        private System.Windows.Forms.Label label184;
        private System.Windows.Forms.Label label185;
        private System.Windows.Forms.Label label186;
        private System.Windows.Forms.Label label187;
        private System.Windows.Forms.Label label188;
        private System.Windows.Forms.Label label189;
        private System.Windows.Forms.Label label190;
        private System.Windows.Forms.Label label191;
        private System.Windows.Forms.Label label192;
        private System.Windows.Forms.Label label193;
        private System.Windows.Forms.Label label194;
        private System.Windows.Forms.Label label195;
        private System.Windows.Forms.Label label196;
        private System.Windows.Forms.Label label199;
        private System.Windows.Forms.Label label198;
        private System.Windows.Forms.Label label200;
        private System.Windows.Forms.Label label201;
        private System.Windows.Forms.Label label202;
        private System.Windows.Forms.Label label203;
        private System.Windows.Forms.Label label204;
        private System.Windows.Forms.Label label205;
        private System.Windows.Forms.Label label206;
        private System.Windows.Forms.Label label207;
        private System.Windows.Forms.Label label208;
        private System.Windows.Forms.Label label209;
        private System.Windows.Forms.Label label210;
        private System.Windows.Forms.Label label211;
        private System.Windows.Forms.Label label212;
        private System.Windows.Forms.Label label213;
        private System.Windows.Forms.Label label214;
        private System.Windows.Forms.Label label197;
        private System.Windows.Forms.Label label215;
        private System.Windows.Forms.Label label216;
        private System.Windows.Forms.Label label217;
        private System.Windows.Forms.Label label218;
        private System.Windows.Forms.Label label219;
        private System.Windows.Forms.Label label220;
        private System.Windows.Forms.Label label221;
        private System.Windows.Forms.Label label222;
        private System.Windows.Forms.Label label223;
        private System.Windows.Forms.Label label224;
        private System.Windows.Forms.Label label225;
        private System.Windows.Forms.Label label226;
        private System.Windows.Forms.Label label227;
        private System.Windows.Forms.Label label228;
        private System.Windows.Forms.Label label229;
        private System.Windows.Forms.Label label230;
        private System.Windows.Forms.Label label231;
        private System.Windows.Forms.Label label232;
        private System.Windows.Forms.Label label233;
        private System.Windows.Forms.Label label234;
        private System.Windows.Forms.Label label235;
        private System.Windows.Forms.Label label236;
        private System.Windows.Forms.Label label237;
        private System.Windows.Forms.Label label238;
        private System.Windows.Forms.Label label239;
        private System.Windows.Forms.Label label240;
        private System.Windows.Forms.Label label241;
        private System.Windows.Forms.Label label242;
        private System.Windows.Forms.Label label243;
        private System.Windows.Forms.Label label244;
        private System.Windows.Forms.Label label245;
        private System.Windows.Forms.Label label246;
        private System.Windows.Forms.Label label247;
        private System.Windows.Forms.Label label248;
        private System.Windows.Forms.Label label249;
        private System.Windows.Forms.Label label250;
        private System.Windows.Forms.Label label251;
        private System.Windows.Forms.Label label252;
        private System.Windows.Forms.Label label256;
        private System.Windows.Forms.Label label257;
        private System.Windows.Forms.Label label258;
        private System.Windows.Forms.Label label259;
        private System.Windows.Forms.Label label260;
        private System.Windows.Forms.Label label261;
        private System.Windows.Forms.Label label262;
        private System.Windows.Forms.Label label263;
        private System.Windows.Forms.Label label264;
        private System.Windows.Forms.Label label265;
        private System.Windows.Forms.Label label272;
        private System.Windows.Forms.Label label273;
        private System.Windows.Forms.Label label274;
        private System.Windows.Forms.Label label280;
        private System.Windows.Forms.Label label281;
        private System.Windows.Forms.Label label282;
        private System.Windows.Forms.Label label283;
        private System.Windows.Forms.Label label284;
        private System.Windows.Forms.Label label266;
        private System.Windows.Forms.Label label267;
        private System.Windows.Forms.Label label268;
        private System.Windows.Forms.Label label269;
        private System.Windows.Forms.Label label270;
        private System.Windows.Forms.Label label271;
        private System.Windows.Forms.Label label275;
        private System.Windows.Forms.Label label276;
        private System.Windows.Forms.Label label277;
        private System.Windows.Forms.Label label278;
        private System.Windows.Forms.Label label279;
        private System.Windows.Forms.Label label285;
        private System.Windows.Forms.Label label286;
        private System.Windows.Forms.Label label287;
        private System.Windows.Forms.Label label288;
        private System.Windows.Forms.Label label289;
        private System.Windows.Forms.Label label290;
        private System.Windows.Forms.Label label293;
        private System.Windows.Forms.Label label294;
        private System.Windows.Forms.Label label295;
        private System.Windows.Forms.Label label296;
        private System.Windows.Forms.Label label297;
        private System.Windows.Forms.Label label298;
        private System.Windows.Forms.Label label299;
        private System.Windows.Forms.Label label300;
        private System.Windows.Forms.Label label301;
        private System.Windows.Forms.Label label302;
        private System.Windows.Forms.Label label291;
        private System.Windows.Forms.Label label292;
        private System.Windows.Forms.Label label303;
        private System.Windows.Forms.Label label304;
        private System.Windows.Forms.Label label305;
        private System.Windows.Forms.Label label306;
        private System.Windows.Forms.Label label307;
        private System.Windows.Forms.Label label308;
        private System.Windows.Forms.Label label309;
        private System.Windows.Forms.Label label310;
        private System.Windows.Forms.Label label311;
        private System.Windows.Forms.Label label312;
        private System.Windows.Forms.Label label313;
        private System.Windows.Forms.Label label314;
        private System.Windows.Forms.Label label315;
        private System.Windows.Forms.Label label316;
        private System.Windows.Forms.Label label317;
        private System.Windows.Forms.Label label318;
        private System.Windows.Forms.Label label319;
        private System.Windows.Forms.Label label320;
        private System.Windows.Forms.Label label321;
        private System.Windows.Forms.Label label322;
        private System.Windows.Forms.Label label323;
        private System.Windows.Forms.Label label324;
        private System.Windows.Forms.Label label325;
        private System.Windows.Forms.Label label327;
        private System.Windows.Forms.Label label326;
        private System.Windows.Forms.Label label328;
        private System.Windows.Forms.Label label329;
        private System.Windows.Forms.Label label330;
        private System.Windows.Forms.Label label331;
        private System.Windows.Forms.Label label332;
        private System.Windows.Forms.Label label333;
        private System.Windows.Forms.Label label334;
        private System.Windows.Forms.Label label335;
        private System.Windows.Forms.Label label336;
        private System.Windows.Forms.Label label337;
        private System.Windows.Forms.Label label338;
        private System.Windows.Forms.Label label339;
        private System.Windows.Forms.Label label340;
        private System.Windows.Forms.Label label341;
        private System.Windows.Forms.Timer timer8;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pacman;
        private System.Windows.Forms.Timer powermod;
        private System.Windows.Forms.Timer timer7;
        private System.Windows.Forms.Timer timer9;
        private System.Windows.Forms.Timer ghostmangiato;
        private System.Windows.Forms.Label label124;
        private System.Windows.Forms.Label label141;
        private System.Windows.Forms.Timer powermod1;
        private System.Windows.Forms.Timer attendo;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Label label254;
        private System.Windows.Forms.Label label255;
        private System.Windows.Forms.Label label253;
        private System.Windows.Forms.Label label142;
    }
}

